/* Pembuat laporan titik panas – Pantau Rimbak Nanga Lauk
 * Semua laporan dibuat di browser pengguna dari basis data website (data/web/YYYY.json),
 * data cuaca (data/cuaca.json), batas wilayah (data/geo.json) dan kejadian api (data/kejadian.json).
 * Keluaran: pratinjau di layar, PDF (jsPDF + autoTable), Word (docx), dan CSV.
 */
(function () {
'use strict';
const $ = s => document.querySelector(s);
const ZONES = ['Hutan Desa', 'Desa Nanga Lauk', 'Radius 5 km', 'Radius 5-25 km', 'Kapuas Hulu', 'Luar Kapuas Hulu'];
const ZCOL = ['#C21D1D', '#E2621B', '#E8A317', '#C9B21E', '#8E7A9E', '#9AA49E'];
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const BULAN_P = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const HEAD = '#22382B', INK = '#1D2A22', MUTED = '#5B6A61', LINE = '#D3DBD5';
const WIL = {
  desa25: { nama: 'Desa Nanga Lauk & radius 25 km', zmax: 3, ext: 'buf25' },
  desa5: { nama: 'Hutan Desa, Desa Nanga Lauk & radius 5 km', zmax: 2, ext: 'buf5' },
  kh: { nama: 'Seluruh Kabupaten Kapuas Hulu', zmax: 4, ext: 'kh' },
};
const CAP_DETAIL = 220, CAP_EVENTS = 40;
let LOGO = null, G = null, G0 = null, STATUS = null, EVENTS = null, CUACA = null, IMG = null, IMG0 = null, SI = 0, SITE = null; const YEARS = {}, CUACAS = {};
let LAST = null;

/* ---------------- util ---------------- */
const fmt = n => Number(n).toLocaleString('id-ID');
const fmt1 = n => Number(n).toLocaleString('id-ID', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const iso = d => d.toISOString().slice(0, 10);
const D = s => new Date(s + 'T00:00:00Z');
const addDays = (s, n) => iso(new Date(D(s).getTime() + n * 864e5));
const daysBetween = (a, b) => Math.round((D(b) - D(a)) / 864e5) + 1;
const tglID = s => `${+s.slice(8, 10)} ${BULAN_P[+s.slice(5, 7) - 1]} ${s.slice(0, 4)}`;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const famOf = sen => sen.startsWith('MODIS') ? 'MODIS' : sen.includes('S-NPP') ? 'VIIRS S-NPP' : sen.includes('NOAA-20') ? 'VIIRS NOAA-20' : 'VIIRS NOAA-21';
const confTxt = r => r.sen.startsWith('MODIS') ? r.conf + '%' : ({ l: 'rendah', n: 'nominal', h: 'tinggi' }[r.conf] || r.conf);
function loadScript(src) { return new Promise((ok, no) => { if (document.querySelector(`script[src="${src}"]`)) return ok(); const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => no(new Error('Gagal memuat ' + src)); document.head.appendChild(s); }); }
const status = (t, err) => { const el = $('#rpStatus'); el.textContent = t; el.style.color = err ? 'var(--z-hd)' : 'var(--muted)'; };

async function base() {
  if (G0) return setSite(window.FH_SITE);
  const j = u => fetch(u + '?' + Date.now()).then(r => { if (!r.ok) throw new Error(u); return r.json(); });
  [G0, STATUS, EVENTS, CUACA] = await Promise.all([j('data/geo.json'), j('data/status.json'), j('data/kejadian.json'), j('data/cuaca.json')]); G = G0; CUACAS.nangalauk = CUACA;
  if (!Array.isArray(EVENTS)) EVENTS = EVENTS.baris.map(r => Object.fromEntries(EVENTS.kolom.map((k, i) => [k, r[i]])));
  IMG0 = await new Promise(ok => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = 'assets/s2_20260810.jpg'; });
  LOGO = await new Promise(ok => { const im = new Image(); im.onload = () => { const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); ok({ c, url: c.toDataURL('image/jpeg', 0.95), r: im.naturalHeight / im.naturalWidth }); }; im.onerror = () => ok(null); im.src = 'assets/logo_prcf.jpg'; });
  if (!window.__PRL) window.__PRL = await new Promise(ok => { const im = new Image(); im.onload = () => { const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); ok({ c, url: c.toDataURL('image/png') }); }; im.onerror = () => ok(null); im.src = 'assets/logo_pr_256.png'; });
  await setSite(window.FH_SITE);
}
/* ---------------- lokasi Hutan Desa yang dipilih ---------------- */
async function setSite(id) {
  const S = G0.sites || []; SI = Math.max(0, S.findIndex(x => x.id === id)); SITE = S[SI] || null;
  if (!SITE) { G = G0; IMG = IMG0; return; }
  const nl = SITE.id === 'nangalauk';
  G = Object.assign({}, G0, { desa: SITE.desa, hd: SITE.hd, buf5: SITE.buf5, buf25: SITE.buf25, grid: nl ? G0.grid : { type: 'FeatureCollection', features: [] } });
  IMG = nl ? IMG0 : null;
  ZONES[1] = 'Desa ' + SITE.desa_nama;
  WIL.desa25.nama = `${SITE.hd_nama}, Desa ${SITE.desa_nama} & radius 25 km`;
  WIL.desa5.nama = `${SITE.hd_nama}, Desa ${SITE.desa_nama} & radius 5 km`;
  if (!CUACAS[SITE.id]) { try { const r = await fetch(`data/cuaca_${SITE.id}.json?${Date.now()}`); if (r.ok) CUACAS[SITE.id] = await r.json(); } catch (e) { } }
  CUACA = CUACAS[SITE.id] || CUACAS.nangalauk;
}
const zoneOfCode = (c, kab) => c < 0 ? 0 : c === 0 ? 1 : c <= 5 ? 2 : c <= 25 ? 3 : kab === 'Kapuas Hulu' ? 4 : 5;
function siteRow(r) { if (!SITE || !r.ls || r.ls.length <= SI) return r; const c = r.ls[SI]; return Object.assign({}, r, { z: zoneOfCode(c, r.kab), km: Math.max(0, c) }); }
async function yearData(y) {
  if (YEARS[y]) return YEARS[y];
  const r = await fetch(`data/web/${y}.json?${Date.now()}`); if (!r.ok) return (YEARS[y] = []);
  const j = await r.json(); const K = j.kolom;
  return (YEARS[y] = j.baris.map(a => Object.fromEntries(K.map((k, i) => [k, a[i]]))));
}

/* ---------------- cakupan data ---------------- */
function coverage() {
  const c = STATUS.cakupan || {}; let spEnd = '2000-10-31', nrtStart = null, nrtEnd = null;
  for (const [k, v] of Object.entries(c)) {
    if (k.startsWith('SP ')) { const yEnd = v[1].slice(0, 4) + '-12-31'; if (yEnd > spEnd) spEnd = yEnd; }
    else { if (!nrtStart || v[0] < nrtStart) nrtStart = v[0]; if (!nrtEnd || v[1] > nrtEnd) nrtEnd = v[1]; }
  }
  return { start: '2000-11-01', spEnd, nrtStart, end: nrtEnd || spEnd };
}
function gapIn(a, b) {
  const cv = coverage(); if (!cv.nrtStart) return null;
  const g0 = addDays(cv.spEnd, 1), g1 = addDays(cv.nrtStart, -1); if (g1 < g0) return null;
  const s = a > g0 ? a : g0, e = b < g1 ? b : g1; return s <= e ? [s, e] : null;
}

/* ---------------- cuaca ---------------- */
function rainStats(a, b) {
  const t = CUACA.t; let i0 = t.findIndex(x => x >= a); if (i0 < 0) return null; let n = 0, sum = 0, wet = 0, rh = 0, tm = -99, dry = 0, maxDry = 0, dryEnd = null;
  for (let i = i0; i < t.length && t[i] <= b; i++) {
    const h = CUACA.hujan[i] ?? 0; n++; sum += h; rh += CUACA.rh[i] ?? 0; tm = Math.max(tm, CUACA.tmaks[i] ?? -99);
    if (h >= 1) { wet++; dry = 0; } else { dry++; if (dry > maxDry) { maxDry = dry; dryEnd = t[i]; } }
  }
  if (!n) return null;
  return { n, sum, wet, rhMean: rh / n, tMax: tm, maxDry, dryEnd, last: t[t.length - 1] };
}
function rainNormal(a, b) {
  const len = daysBetween(a, b); if (len > 366) return null; const vals = [];
  for (let y = 2001; y <= 2025; y++) {
    const dy = +a.slice(0, 4) - y; const a2 = y + a.slice(4); if (isNaN(D(a2))) continue; const e2 = addDays(a2, len - 1);
    if (a2.slice(0, 4) == a.slice(0, 4) && dy === 0) continue;
    const s = rainStats(a2, e2); if (s && s.n === len) vals.push(s.sum);
  }
  return vals.length ? vals.reduce((p, c) => p + c, 0) / vals.length : null;
}
function monthlyRain(ym) { let s = 0, n = 0; CUACA.t.forEach((t, i) => { if (t.startsWith(ym)) { s += CUACA.hujan[i] ?? 0; n++; } }); return n ? s : null; }

/* ---------------- model laporan ---------------- */
async function buildModel(a, b, wilKey, sensor) {
  await base(); const W = WIL[wilKey];
  const years = []; for (let y = +a.slice(0, 4); y <= +b.slice(0, 4); y++) years.push(y);
  const all = (await Promise.all(years.map(yearData))).flat().map(siteRow);
  const rows = all.filter(r => r.d >= a && r.d <= b && r.z <= W.zmax && (sensor === 'semua' || (sensor === 'viirs' ? !r.sen.startsWith('MODIS') : r.sen.startsWith('MODIS'))));
  rows.sort((x, y) => (x.d + x.t).localeCompare(y.d + y.t));
  const len = daysBetween(a, b), gap = gapIn(a, b), zc = ZONES.map((_, i) => rows.filter(r => r.z === i).length);
  const near = rows.filter(r => r.z <= 2), fams = ['MODIS', 'VIIRS S-NPP', 'VIIRS NOAA-20', 'VIIRS NOAA-21'];
  const rs = rainStats(a, b), rn = rs ? rainNormal(a, b) : null;
  // pembanding: VIIRS S-NPP periode sama 2013–2025
  let trend = null;
  if (len <= 366 && !gapIn(a, b)) {
    const vs = []; const yA = +a.slice(0, 4);
    for (let y = 2013; y <= 2025; y++) {
      if (y === yA && +b.slice(0, 4) === yA) continue;
      const a2 = y + a.slice(4), b2 = (y + (+b.slice(0, 4) - yA)) + b.slice(4); if (isNaN(D(a2)) || isNaN(D(b2))) continue; const yd = (await Promise.all([y, y + (+b.slice(0, 4) - yA)].filter((v, i, s) => s.indexOf(v) === i).map(yearData))).flat().map(siteRow);
      vs.push(yd.filter(r => r.d >= a2 && r.d <= b2 && r.z <= W.zmax && r.sen.includes('S-NPP')).length);
    }
    const cur = rows.filter(r => r.sen.includes('S-NPP')).length;
    if (vs.length) trend = { mean: vs.reduce((p, c) => p + c, 0) / vs.length, min: Math.min(...vs), max: Math.max(...vs), cur, n: vs.length };
  }
  // periode tabel
  const unit = len <= 62 ? 'hari' : len <= 731 ? 'bulan' : 'tahun';
  const keyOf = d => unit === 'hari' ? d : unit === 'bulan' ? d.slice(0, 7) : d.slice(0, 4);
  const keys = []; { let d = a; while (d <= b) { const k = keyOf(d); if (keys[keys.length - 1] !== k) keys.push(k); d = unit === 'tahun' ? (+d.slice(0, 4) + 1) + '-01-01' : unit === 'bulan' ? (d.slice(5, 7) === '12' ? (+d.slice(0, 4) + 1) + '-01-01' : d.slice(0, 5) + String(+d.slice(5, 7) + 1).padStart(2, '0') + '-01') : addDays(d, 1); } }
  const rainOf = k => { const s = unit === 'hari' ? k : unit === 'bulan' ? (k + '-01' < a ? a : k + '-01') : (k + '-01-01' < a ? a : k + '-01-01'); const e0 = unit === 'hari' ? k : unit === 'bulan' ? iso(new Date(Date.UTC(+k.slice(0, 4), +k.slice(5, 7), 0))) : k + '-12-31'; const e = e0 > b ? b : e0; const st = rainStats(s, e); return st && st.n === daysBetween(s, e) ? st.sum : (st ? st.sum : null); };
  const per = keys.map(k => { const rk = rows.filter(r => keyOf(r.d) === k); return { k, z: ZONES.slice(0, W.zmax + 1).map((_, i) => rk.filter(r => r.z === i).length), n: rk.length, rain: rainOf(k) }; });
  // kejadian
  const evMap = new Map(); for (const e of EVENTS) evMap.set(e.id_kejadian, e);
  const evg = new Map(); for (const r of near) if (r.ev) { if (!evg.has(r.ev)) evg.set(r.ev, []); evg.get(r.ev).push(r); }
  const events = [...evg.entries()].map(([id, rr]) => { const e = evMap.get(id) || {}; return { id, mulai: rr[0].wib, selesai: rr[rr.length - 1].wib, n: rr.length, z: Math.min(...rr.map(r => r.z)), pt: [...new Set(rr.map(r => r.pt).filter(Boolean))].join(', '), frp: Math.max(...rr.map(r => r.frp)), ha: e.luas_cakupan_piksel_ha ?? rr.reduce((s, r) => s + r.ha, 0) }; })
    .sort((x, y) => x.z - y.z || y.mulai.localeCompare(x.mulai));
  const petak = {}; for (const r of near) if (r.pt) (petak[r.pt] = petak[r.pt] || []).push(r.wib.slice(0, 10));
  const ctx = k => { const c = {}; for (const r of near) { const v = (r[k] || 'Tidak ada / di luar data').split(' (')[0]; c[v] = (c[v] || 0) + 1; } return Object.entries(c).sort((x, y) => y[1] - x[1]); };
  const M = { a, b, len, W, wilKey, sensor, rows, near, zc, fams, gap, rs, rn, trend, unit, per, events, petak, ctx: { kw: ctx('kw'), tl: ctx('tl'), gb: ctx('gb') }, cov: coverage() };
  M.title = `Laporan Titik Panas ${W.nama}`;
  M.periodeTxt = `${tglID(a)} – ${tglID(b)}`;
  M.summary = summary(M); M.weatherTxt = weatherText(M);
  try { M.lk = SITE ? await fetch(`data/lahan_kritis/${SITE.id}.json`, { cache: 'no-cache' }).then(r => r.ok ? r.json() : null) : null; } catch (e) { M.lk = null; }
  try { M.karbon = window.FHKarbon && SITE ? await FHKarbon.ringkas(SITE.id, +a.slice(0, 4), +b.slice(0, 4)) : null; } catch (e) { M.karbon = null; }
  M.ex = await extras(M); M.summary.push(...extraSummary(M)); M.checks = verify(M); M.dibuat = new Date().toLocaleString('id-ID');
  return M;
}

function summary(M) {
  const s = []; const z = M.zc;
  s.push(`Periode ${M.periodeTxt} (${fmt(M.len)} hari), wilayah ${M.W.nama}, sensor ${M.sensor === 'semua' ? 'VIIRS & MODIS' : M.sensor.toUpperCase()}: ${fmt(M.rows.length)} deteksi titik panas.`);
  const hd = M.rows.filter(r => r.z === 0);
  s.push(`Di dalam Hutan Desa: ${z[0]} deteksi` + (hd.length ? ' (' + hd.slice(0, 6).map(r => `${r.wib} WIB${r.pt ? ', petak ' + r.pt : ''}`).join('; ') + (hd.length > 6 ? '; …' : '') + ').' : '.'));
  s.push(`Di dalam ${ZONES[1]} (di luar Hutan Desa): ${z[1]}; radius 0–5 km dari batas desa: ${z[2]}` + (M.W.zmax >= 3 ? `; radius 5–25 km: ${fmt(z[3])}` : '') + (M.W.zmax >= 4 ? `; bagian lain Kapuas Hulu: ${fmt(z[4])}` : '') + '.');
  s.push(`Kejadian api (deteksi berjarak ≤ 1 km dan ≤ 2 hari) di desa dan radius 5 km: ${M.events.length}.`);
  if (M.trend) {
    const t = M.trend, r = t.mean ? t.cur / t.mean : null;
    s.push(`Dibanding periode yang sama tahun 2013–2025 (sensor VIIRS S-NPP, rata-rata ${fmt1(t.mean)} deteksi, rentang ${t.min}–${t.max}), periode ini ${t.cur} deteksi: ` + (r === null ? 'tidak dapat dibandingkan.' : r < 0.5 ? 'jauh di bawah rata-rata.' : r < 0.85 ? 'di bawah rata-rata.' : r <= 1.15 ? 'mendekati rata-rata.' : r <= 2 ? 'di atas rata-rata.' : 'jauh di atas rata-rata.'));
  }
  if (M.gap) s.push(`PERHATIAN: tanggal ${tglID(M.gap[0])} – ${tglID(M.gap[1])} belum memiliki data FIRMS di basis data (menunggu arsip tahunan NASA). Nol deteksi pada rentang ini BUKAN berarti tidak ada titik panas.`);
  return s;
}

function monthStats(ym) { const a = ym + '-01', b = iso(new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 0))); return rainStats(a, b); }
function monthNormal(m) { let s = 0; const ys = new Set(); CUACA.t.forEach((t, i) => { if (t >= '2001' && t < '2026' && +t.slice(5, 7) === m) { s += CUACA.hujan[i] ?? 0; ys.add(t.slice(0, 4)); } }); return ys.size ? s / ys.size : null; }
function weatherText(M) {
  const rs = M.rs; if (!rs) return ['Data cuaca untuk periode ini belum tersedia.'];
  const out = []; const many = M.zc[0] + M.zc[1] + M.zc[2];
  const gapBig = M.gap && daysBetween(M.gap[0], M.gap[1]) >= M.len * 0.5;
  const mc = {}; for (const r of M.rows) { const m = +r.d.slice(5, 7); mc[m] = (mc[m] || 0) + 1; }
  const topM = Object.entries(mc).sort((x, y) => y[1] - x[1]).slice(0, 3);
  if (M.len > 366) {
    // ---- rentang panjang: pola tahunan
    const yrs = []; for (let y = +M.a.slice(0, 4); y <= +M.b.slice(0, 4); y++) { const full = `${y}-01-01` >= M.a && `${y}-12-31` <= M.b && `${y}-12-31` <= rs.last; if (full) yrs.push(y); }
    const ann = yrs.map(y => ({ y, rain: rainStats(`${y}-01-01`, `${y}-12-31`).sum, dry: rainStats(`${y}-06-01`, `${y}-09-30`), modis: M.rows.filter(r => r.d.startsWith(String(y)) && r.sen.startsWith('MODIS')).length, all: M.rows.filter(r => r.d.startsWith(String(y))).length }));
    if (ann.length) {
      const mean = ann.reduce((p, c) => p + c.rain, 0) / ann.length, jjas = ann.reduce((p, c) => p + c.dry.sum, 0) / ann.length;
      const wet = ann.reduce((p, c) => c.rain > p.rain ? c : p), dryY = ann.reduce((p, c) => c.dry.sum < p.dry.sum ? c : p);
      out.push(`Curah hujan rata-rata ${fmt(Math.round(mean))} mm per tahun (${ann[0].y}–${ann[ann.length - 1].y}); musim kemarau Juni–September rata-rata ${fmt(Math.round(jjas))} mm. Tahun terbasah ${wet.y} (${fmt(Math.round(wet.rain))} mm); kemarau terkering ${dryY.y} (Juni–September ${fmt(Math.round(dryY.dry.sum))} mm, ${Math.round(dryY.dry.sum / jjas * 100)}% dari rata-rata, kering beruntun terpanjang ${dryY.dry.maxDry} hari).`);
      const top = ann.slice().sort((x, y) => y.all - x.all).slice(0, 3);
      out.push(`Tahun dengan titik panas terbanyak: ${top.map(t => `${t.y} (${fmt(t.all)} deteksi; hujan Juni–September ${Math.round(t.dry.sum / jjas * 100)}% dari rata-rata, kering beruntun ${t.dry.maxDry} hari)`).join('; ')}.`);
      const xs = ann.map(a => a.dry.sum), ys = ann.map(a => a.modis); const n = xs.length;
      if (n >= 5 && ys.some(v => v)) { const mx = xs.reduce((p, c) => p + c, 0) / n, my = ys.reduce((p, c) => p + c, 0) / n; let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; } const r = sxy / Math.sqrt(sxx * syy || 1);
        out.push(`Hubungan curah hujan kemarau dengan jumlah titik panas (MODIS, ${n} tahun penuh): koefisien korelasi r = ${window.FHLang ? FHLang.desimal(r.toFixed(2)) : r.toFixed(2).replace('.', ',')}. ` + (r <= -0.5 ? 'Hubungannya kuat dan negatif: semakin kering musim kemarau, semakin banyak titik panas.' : r <= -0.3 ? 'Hubungannya sedang dan negatif: kemarau yang lebih kering cenderung disertai lebih banyak titik panas.' : 'Hubungannya lemah; faktor lain seperti pembukaan ladang dan kegiatan manusia ikut menentukan jumlah titik panas.')); }
    }
  } else {
    const pct = M.rn ? rs.sum / M.rn * 100 : null;
    const kond = pct === null ? null : pct < 60 ? 'jauh lebih kering dari normal' : pct < 85 ? 'lebih kering dari normal' : pct <= 115 ? 'normal' : pct <= 150 ? 'lebih basah dari normal' : 'jauh lebih basah dari normal';
    out.push(`Curah hujan total ${fmt1(rs.sum)} mm dalam ${rs.n} hari (${rs.wet} hari hujan ≥ 1 mm)` + (M.rn ? `; sebagai pembanding, rata-rata jangka panjang untuk tanggal yang sama tahun 2001–2025 adalah ${fmt1(M.rn)} mm (${Math.round(pct)}% dari normal, kondisi ${kond}).` : '.') +
      ` Periode kering terpanjang (hujan < 1 mm/hari berturut-turut): ${rs.maxDry} hari${rs.maxDry ? ' (berakhir ' + tglID(rs.dryEnd) + ')' : ''}. Kelembapan rata-rata ${fmt1(rs.rhMean)}%, suhu maksimum ${fmt1(rs.tMax)} °C.`);
    if (M.len > 62 && M.rows.length) {
      const ymC = {}; for (const r of M.rows) { const k = r.d.slice(0, 7); ymC[k] = (ymC[k] || 0) + 1; }
      const [pk, pn] = Object.entries(ymC).sort((x, y) => y[1] - x[1])[0]; const st = monthStats(pk), nm = monthNormal(+pk.slice(5, 7));
      if (st) out.push(`Bulan dengan titik panas terbanyak: ${BULAN_P[+pk.slice(5, 7) - 1]} ${pk.slice(0, 4)} (${pn} deteksi). Curah hujan bulan itu ${fmt1(st.sum)} mm` + (nm ? ` (${Math.round(st.sum / nm * 100)}% dari rata-rata jangka panjang ${BULAN_P[+pk.slice(5, 7) - 1]} 2001–2025, ${fmt1(nm)} mm)` : '') + `, ${st.wet} hari hujan, kering beruntun terpanjang ${st.maxDry} hari.`);
      const quiet = Object.keys(Object.fromEntries(M.per.map(p => [p.k, 1]))).filter(k => !ymC[k] && k.length === 7);
      if (quiet.length && quiet.length <= 12) { const qr = quiet.map(k => { const st2 = monthStats(k), nm2 = monthNormal(+k.slice(5, 7)); return st2 && nm2 ? st2.sum / nm2 : null; }).filter(v => v !== null); if (qr.length) out.push(`Bulan tanpa titik panas (${quiet.map(k => BULAN[+k.slice(5, 7) - 1]).join(', ')}) rata-rata menerima ${Math.round(qr.reduce((p, c) => p + c, 0) / qr.length * 100)}% curah hujan normalnya.`); }
    }
    if (rs.last < M.b) out.push(`Data cuaca tersedia sampai ${tglID(rs.last)} (reanalisis ERA5 tertunda beberapa hari).`);
    const dryish = (pct !== null && pct < 85) || rs.maxDry >= 10, wetish = (pct !== null && pct > 115) || (rs.maxDry < 5 && rs.wet / rs.n > 0.5);
    let interp;
    if (gapBig) interp = 'Sebagian besar periode belum memiliki data titik panas, sehingga hubungan cuaca dan titik panas belum dapat disimpulkan.';
    else if (many === 0 && wetish) interp = 'Tidak adanya titik panas di desa dan sekitarnya sejalan dengan kondisi basah: hujan sering turun dan periode kering pendek, sehingga vegetasi, serasah, dan gambut tetap lembap dan api sulit menyala atau menyebar.';
    else if (many === 0 && dryish) interp = 'Meskipun cuaca relatif kering, tidak ada titik panas di desa dan sekitarnya. Ini indikasi baik bahwa tidak ada pembakaran atau api berhasil dicegah; tetap waspada karena kondisi kering meningkatkan risiko.';
    else if (many === 0) interp = 'Tidak ada titik panas di desa dan sekitarnya pada kondisi cuaca yang mendekati normal.';
    else if (dryish) interp = `Titik panas muncul bersamaan dengan kondisi kering (periode tanpa hujan ${rs.maxDry} hari). Pola ini umum di Kapuas Hulu pada musim kemarau (Juni–September), saat pembukaan ladang dengan pembakaran dan lahan lebih mudah terbakar; lokasi di dalam desa perlu dicek lapangan.`;
    else if (wetish) interp = 'Secara keseluruhan periode ini basah, namun titik panas tetap muncul, umumnya pada jeda beberapa hari tanpa hujan. Pola ini khas pembakaran terkendali untuk pembukaan ladang; perlu verifikasi lapangan.';
    else interp = 'Titik panas muncul pada kondisi cuaca mendekati normal; perlu verifikasi lapangan untuk memastikan sumber panas (pembakaran ladang, kebakaran, atau sumber lain).';
    out.push(interp);
  }
  if (gapBig && M.len > 366) out.push('Catatan: sebagian periode belum memiliki data titik panas (lihat Ringkasan), sehingga tahun tersebut tidak dipakai dalam perbandingan.');
  out.push('Pola musim Kapuas Hulu (iklim ekuatorial): hujan tinggi hampir sepanjang tahun dengan puncak Oktober–Desember dan Maret–Mei; periode lebih kering umumnya Juni–September, terutama pada tahun El Niño (mis. 2015, 2019, 2023).' + (topM.length ? ` Titik panas pada periode ini paling banyak di bulan ${topM.map(([m, n]) => `${BULAN_P[m - 1]} (${fmt(n)})`).join(', ')}.` : ''));
  return out;
}

/* ---------------- gambar (canvas) ---------------- */
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); return [c, g]; }
function rings(geom) { const P = geom.type === 'Polygon' ? [geom.coordinates] : geom.type === 'MultiPolygon' ? geom.coordinates : geom.type === 'LineString' ? [[geom.coordinates]] : geom.type === 'MultiLineString' ? [geom.coordinates] : []; return P.flat(); }
function bboxOf(fc) { let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; for (const f of fc.features) for (const r of rings(f.geometry)) for (const [x, y] of r) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); } return [x0, y0, x1, y1]; }
function drawMap(M, which) {
  const [c, g] = mkCanvas(1400, 1150); const pad = 60;
  let bb = which === 'zoom' ? bboxOf(G.buf5) : M.W.ext === 'kh' ? bboxOf({ features: G.kab.features.filter(f => f.properties.WADMKK === 'Kapuas Hulu') }) : bboxOf(G[M.W.ext]);
  const dx = (bb[2] - bb[0]) * 0.04, dy = (bb[3] - bb[1]) * 0.04; bb = [bb[0] - dx, bb[1] - dy, bb[2] + dx, bb[3] + dy];
  const sc = Math.min((c.width - 2 * pad) / (bb[2] - bb[0]), (c.height - 2 * pad - 40) / (bb[3] - bb[1]));
  const ox = pad + ((c.width - 2 * pad) - sc * (bb[2] - bb[0])) / 2, oy = pad + 40;
  const P = (x, y) => [ox + (x - bb[0]) * sc, oy + (bb[3] - y) * sc];
  g.fillStyle = '#F2F4F1'; g.fillRect(ox, oy, sc * (bb[2] - bb[0]), sc * (bb[3] - bb[1]));
  g.save(); g.beginPath(); g.rect(ox, oy, sc * (bb[2] - bb[0]), sc * (bb[3] - bb[1])); g.clip();
  if (which === 'zoom' && IMG) { const [[la0, lo0], [la1, lo1]] = G.img_bounds; const [x0, y0] = P(lo0, la1), [x1, y1] = P(lo1, la0); g.drawImage(IMG, x0, y0, x1 - x0, y1 - y0); }
  const stroke = (fc, col, w, dash, alpha) => { g.strokeStyle = col; g.lineWidth = w; g.setLineDash(dash || []); g.globalAlpha = alpha ?? 1; for (const f of fc.features) for (const r of rings(f.geometry)) { g.beginPath(); r.forEach(([x, y], i) => { const [px, py] = P(x, y); i ? g.lineTo(px, py) : g.moveTo(px, py); }); g.stroke(); } g.setLineDash([]); g.globalAlpha = 1; };
  stroke(G.kab, '#8E9A92', 1.2, [6, 5]); stroke(G.river, '#4A90C8', 1.6, null, 0.85);
  if (which === 'zoom') stroke(G.grid, '#ffffff', 0.6, null, 0.55);
  if (M.W.zmax >= 3 || which === 'zoom') stroke(G.buf5, ZCOL[2], 2, [12, 7]);
  if (which !== 'zoom' && M.W.zmax >= 3) stroke(G.buf25, ZCOL[3], 2, [12, 8]);
  stroke(G.desa, which === 'zoom' ? '#FFE14D' : '#222', 2.6); stroke(G.hd, '#FF3B30', 3.2);
  const pts = which === 'zoom' ? M.near : M.rows;
  for (let zi = M.W.zmax; zi >= 0; zi--) for (const r of pts) if (r.z === zi) { const [px, py] = P(r.lon, r.lat); g.beginPath(); g.arc(px, py, zi <= 1 ? 9 : zi === 2 ? 7 : 5, 0, 7); g.fillStyle = ZCOL[zi]; g.fill(); g.lineWidth = 1.4; g.strokeStyle = which === 'zoom' ? '#fff' : '#000'; g.stroke(); }
  g.restore();
  g.strokeStyle = MUTED; g.lineWidth = 1.5; g.strokeRect(ox, oy, sc * (bb[2] - bb[0]), sc * (bb[3] - bb[1]));
  g.fillStyle = INK; g.font = 'bold 30px Arial'; g.fillText(which === 'zoom' ? (IMG ? `Titik panas di desa & radius 5 km (latar Sentinel-2, 10 Agu 2026)` : `Titik panas di Hutan Desa, ${ZONES[1]} & radius 5 km`) : `Peta titik panas – ${M.W.nama}`, pad, 44);
  // grid koordinat
  g.font = '20px Arial'; g.fillStyle = MUTED; const step = (bb[2] - bb[0]) > 1 ? 0.5 : (bb[2] - bb[0]) > 0.3 ? 0.1 : 0.05;
  for (let x = Math.ceil(bb[0] / step) * step; x < bb[2]; x += step) { const [px] = P(x, bb[1]); g.fillText(x.toFixed(2) + '°BT', px - 40, oy + sc * (bb[3] - bb[1]) + 26); }
  for (let y = Math.ceil(bb[1] / step) * step; y < bb[3]; y += step) { const [, py] = P(bb[0], y); g.save(); g.translate(ox - 10, py + 40); g.rotate(-Math.PI / 2); g.fillText(y.toFixed(2) + '°LU', 0, 0); g.restore(); }
  // legenda
  const items = [['#FF3B30', 'Hutan Desa', 'l'], [which === 'zoom' ? '#FFE14D' : '#222', ZONES[1], 'l']];
  for (let zi = 0; zi <= (which === 'zoom' ? 2 : M.W.zmax); zi++) items.push([ZCOL[zi], `${ZONES[zi]} (${(which === 'zoom' ? M.near : M.rows).filter(r => r.z === zi).length})`, 'p']);
  const lx = ox + 14, lh = 30; let ly = oy + 14; g.fillStyle = 'rgba(255,255,255,.9)'; g.fillRect(lx - 8, ly - 8, 400, items.length * lh + 12);
  for (const [col, t, k] of items) { if (k === 'l') { g.strokeStyle = col; g.lineWidth = 4; g.beginPath(); g.moveTo(lx, ly + 12); g.lineTo(lx + 30, ly + 12); g.stroke(); } else { g.beginPath(); g.arc(lx + 15, ly + 12, 8, 0, 7); g.fillStyle = col; g.fill(); g.strokeStyle = '#000'; g.lineWidth = 1; g.stroke(); } g.fillStyle = INK; g.font = '21px Arial'; g.fillText(t, lx + 42, ly + 19); ly += lh; }
  return c;
}
function drawChart(title, labels, series, opts = {}) {
  // series: [{name, color, values, type:'bar'|'line', axis:'l'|'r'}]
  const [c, g] = mkCanvas(1400, 560); const L = 90, R = opts.right ? 100 : 30, T = 70, B = 90; const W = c.width - L - R, H = c.height - T - B;
  const bars = series.filter(s => s.type !== 'line'), lines = series.filter(s => s.type === 'line');
  const tot = labels.map((_, i) => bars.reduce((p, s) => p + (s.values[i] || 0), 0)); const mx = Math.max(1, ...tot);
  const nice = v => { const e = Math.pow(10, Math.floor(Math.log10(v))); const f = v / e; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * e; };
  const top = Math.max(5, nice(mx * 1.12)); const rmx = lines.length ? nice(Math.max(1, ...lines.flatMap(s => s.values.map(v => v || 0))) * 1.1) : 1;
  g.fillStyle = INK; g.font = 'bold 30px Arial'; g.fillText(title, 20, 42);
  g.font = '19px Arial'; for (let i = 0; i <= 5; i++) { const y = T + H * (1 - i / 5); g.strokeStyle = LINE; g.lineWidth = 1; g.beginPath(); g.moveTo(L, y); g.lineTo(L + W, y); g.stroke(); g.fillStyle = MUTED; g.textAlign = 'right'; g.fillText(fmt(Math.round(top * i / 5)), L - 10, y + 6); if (opts.right) { g.textAlign = 'left'; g.fillText(fmt(Math.round(rmx * i / 5)), L + W + 10, y + 6); } }
  g.textAlign = 'left'; const bw = W / labels.length;
  if (opts.gap) { opts.gap.forEach((on, i) => { if (!on) return; g.fillStyle = '#ECEEEC'; g.fillRect(L + i * bw, T, bw, H); g.save(); g.translate(L + i * bw + bw / 2, T + H / 2); g.rotate(-Math.PI / 2); g.fillStyle = '#8A948D'; g.font = '17px Arial'; g.textAlign = 'center'; g.fillText('belum ada data titik panas', 0, 6); g.restore(); }); g.textAlign = 'left'; }
  labels.forEach((lab, i) => { let acc = 0; for (const s of bars) { const v = s.values[i] || 0; if (!v) continue; const h = H * v / top; g.fillStyle = s.color; g.fillRect(L + i * bw + bw * 0.12, T + H - H * (acc + v) / top, bw * 0.76, h); acc += v; }
    if (acc && labels.length <= 40) { g.fillStyle = INK; g.font = '17px Arial'; g.textAlign = 'center'; g.fillText(fmt(acc), L + i * bw + bw / 2, T + H - H * acc / top - 6); }
    const every = Math.ceil(labels.length / 24); if (i % every === 0) { g.save(); g.fillStyle = MUTED; g.font = '17px Arial'; g.translate(L + i * bw + bw / 2, T + H + 14); g.rotate(labels.length > 12 ? -Math.PI / 4 : 0); g.textAlign = labels.length > 12 ? 'right' : 'center'; g.fillText(lab, 0, 12); g.restore(); } });
  g.textAlign = 'left';
  for (const s of lines) { g.strokeStyle = s.color; g.lineWidth = 3; g.beginPath(); s.values.forEach((v, i) => { if (v === null || v === undefined) return; const x = L + i * bw + bw / 2, y = T + H - H * v / rmx; i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke(); s.values.forEach((v, i) => { if (v === null) return; g.beginPath(); g.arc(L + i * bw + bw / 2, T + H - H * v / rmx, 4, 0, 7); g.fillStyle = s.color; g.fill(); }); }
  g.font = '19px Arial'; g.fillStyle = MUTED; g.save(); g.translate(24, T + H / 2 + 60); g.rotate(-Math.PI / 2); g.fillText(opts.ylab || 'Jumlah deteksi', 0, 0); g.restore();
  if (opts.right) { g.save(); g.translate(c.width - 20, T + H / 2 - 60); g.rotate(Math.PI / 2); g.fillText(opts.rlab, 0, 0); g.restore(); }
  let lx = L; const ly = c.height - 22; if (opts.gap && opts.gap.some(Boolean)) { g.fillStyle = '#ECEEEC'; g.fillRect(lx, ly - 15, 20, 18); g.strokeStyle = '#8A948D'; g.strokeRect(lx, ly - 15, 20, 18); g.fillStyle = INK; g.font = '19px Arial'; g.fillText('Belum ada data', lx + 26, ly); lx += 32 + g.measureText('Belum ada data').width; }
  for (const s of series) { g.fillStyle = s.color; if (s.type === 'line') { g.fillRect(lx, ly - 8, 28, 4); } else g.fillRect(lx, ly - 15, 20, 18); g.fillStyle = INK; g.fillText(s.name, lx + 34, ly); lx += 44 + g.measureText(s.name).width; }
  return c;
}
function drawContext(M) {
  const [c, g] = mkCanvas(1400, 520); g.fillStyle = INK; g.font = 'bold 30px Arial'; g.fillText('Lokasi titik panas di desa & radius 5 km menurut kawasan, tutupan lahan, dan gambut', 20, 42);
  const sets = [['Fungsi kawasan', M.ctx.kw], ['Tutupan lahan 2026', M.ctx.tl], ['Gambut', M.ctx.gb]];
  sets.forEach(([t, arr], j) => { const x0 = 20 + j * 460, top = 90; g.fillStyle = INK; g.font = 'bold 22px Arial'; g.fillText(t, x0, top); const items = arr.slice(0, 6); const mx = Math.max(1, ...items.map(i => i[1]));
    items.forEach(([k, v], i) => { const y = top + 30 + i * 62; g.font = '18px Arial'; g.fillStyle = MUTED; g.fillText(k.length > 34 ? k.slice(0, 33) + '…' : k, x0, y + 16); g.fillStyle = '#7E9C87'; g.fillRect(x0, y + 24, 320 * v / mx, 22); g.fillStyle = INK; g.fillText(String(v), x0 + 320 * v / mx + 8, y + 42); }); });
  return c;
}

/* ---------------- tabel ---------------- */
function tables(M) {
  const T = {};
  T.zona = [['Zona', ...M.fams, 'Semua']].concat(ZONES.slice(0, M.W.zmax + 1).map((z, i) => [z, ...M.fams.map(f => fmt(M.rows.filter(r => r.z === i && famOf(r.sen) === f).length)), fmt(M.zc[i])]));
  const zn = ['Hutan Desa', 'Desa', '≤ 5 km', '5–25 km', 'Kapuas Hulu lain'].slice(0, M.W.zmax + 1);
  const lab = k => M.unit === 'bulan' ? BULAN[+k.slice(5, 7) - 1] + ' ' + k.slice(0, 4) : M.unit === 'hari' ? tglID(k) : k;
  const inGap = p => { if (!M.gap) return false; const s0 = M.unit === 'hari' ? p.k : M.unit === 'bulan' ? p.k + '-01' : p.k + '-01-01'; const e0 = M.unit === 'hari' ? p.k : M.unit === 'bulan' ? iso(new Date(Date.UTC(+p.k.slice(0, 4), +p.k.slice(5, 7), 0))) : p.k + '-12-31'; return M.gap[0] <= (s0 < M.a ? M.a : s0) && M.gap[1] >= (e0 > M.b ? M.b : e0); };
  T.periode = [[M.unit[0].toUpperCase() + M.unit.slice(1), ...zn, 'Total', 'Hujan (mm)']].concat(M.per.map(p => inGap(p) ? [lab(p.k), ...p.z.map(() => '–'), 'belum ada data', p.rain === null ? '–' : fmt1(p.rain)] : [lab(p.k), ...p.z.map(String), fmt(p.n), p.rain === null ? '–' : fmt1(p.rain)]));
  if (M.unit === 'hari') T.periode = [T.periode[0]].concat(T.periode.slice(1).filter((r, i) => M.per[i].n > 0 || (M.per[i].rain ?? 0) >= 0));
  T.petak = [['Petak', 'Deteksi', 'Tanggal (WIB)']].concat(Object.entries(M.petak).sort((x, y) => y[1].length - x[1].length).map(([p, d]) => [p, String(d.length), [...new Set(d)].join(', ')]));
  T.ev = [['ID kejadian', 'Mulai (WIB)', 'Selesai (WIB)', 'Deteksi', 'Zona', 'Petak', 'FRP maks (MW)', 'Cakupan piksel (ha)']].concat(M.events.slice(0, CAP_EVENTS).map(e => [e.id, e.mulai, e.selesai, String(e.n), ZONES[e.z], e.pt, fmt1(e.frp), fmt1(e.ha)]));
  const det = M.near.length > CAP_DETAIL ? M.near.filter(r => r.z <= 1).concat(M.near.filter(r => r.z === 2).slice(-Math.max(0, CAP_DETAIL - M.near.filter(r => r.z <= 1).length))) : M.near;
  T.detailNote = M.near.length > CAP_DETAIL ? `Ditampilkan ${det.length} dari ${M.near.length} deteksi (semua di Hutan Desa dan desa, serta deteksi radius 5 km terbaru). Daftar lengkap ada di tombol "Unduh data CSV".` : '';
  T.detail = [['No', 'Waktu (WIB)', 'Sensor', 'Lat', 'Lon', 'Keyakinan', 'FRP', 'Zona', 'Jarak (km)', 'Petak', 'Kawasan', 'Tutupan 2026', 'Gambut', 'Status']].concat(det.map((r, i) => [String(i + 1), r.wib, famOf(r.sen), r.lat.toFixed(5), r.lon.toFixed(5), confTxt(r), fmt1(r.frp), ZONES[r.z], r.km.toFixed(2), r.pt, (r.kw || '').split(' (')[0], r.tl, (r.gb || '').split(' (')[0], r.st]));
  T.kamus = [['Istilah', 'Keterangan'], ['Titik panas', 'Pusat piksel satelit yang terdeteksi jauh lebih panas dari sekitarnya (anomali panas), bukan konfirmasi kebakaran'], ['Waktu (WIB)', 'Waktu lintasan satelit (UTC + 7 jam)'], ['Sensor', 'VIIRS 375 m (S-NPP, NOAA-20, NOAA-21) dan MODIS 1 km (Terra, Aqua)'], ['Keyakinan', 'VIIRS: rendah/nominal/tinggi; MODIS: 0–100%'], ['FRP', 'Fire Radiative Power (MW), kekuatan radiasi panas'], ['Zona & jarak', 'Posisi terhadap Hutan Desa/desa dan jarak ke batas desa (km, UTM 49N)'], ['Petak', 'Kode grid patroli 250 m Hutan Desa'], ['Kejadian api', 'Kumpulan deteksi berjarak ≤ 1 km dan ≤ 2 hari'], ['Cakupan piksel', 'Gabungan luas piksel satelit (scan × track), BUKAN luas terbakar'], ['Status', 'SP = arsip final NASA; NRT = Near Real-Time (sementara)']];
  T.kamus.push(['dNBR', 'Selisih Normalized Burn Ratio sebelum–sesudah kebakaran dari citra Sentinel-2; makin besar makin parah (Key & Benson 2006)'], ['FFMC / DC', 'Kode kelembapan bahan bakar halus / kekeringan lapisan dalam pada Canadian Fire Weather Index System'], ['Tingkat FDRS', 'Rendah, Sedang, Tinggi, Ekstrem menurut Fire Danger Rating System Indonesia (de Groot dkk. 2006)'], ['Kehilangan tutupan pohon', 'Hilangnya tajuk pohon (tutupan 2000 ≥ 30%) pada piksel 30 m menurut Hansen/UMD GFC; tidak selalu berarti deforestasi permanen']);
  T.cek = [['Pemeriksaan', 'Hasil', 'Status']].concat(M.checks);
  return T;
}
function sources(M) {
  return [
    ['Titik panas', 'NASA FIRMS (Fire Information for Resource Management System). Arsip tahunan final (SP): MODIS sejak Nov 2000, VIIRS S-NPP sejak 2012, VIIRS NOAA-20 sejak 2018; data terbaru Near Real-Time (VIIRS S-NPP/NOAA-20/NOAA-21, MODIS). DOI: 10.5067/FIRMS/VIIRS/VNP14IMGT_NRT.002; 10.5067/FIRMS/VIIRS/VJ114IMGT_NRT.002; 10.5067/VIIRS/VJ214IMG_NRT.002; 10.5067/FIRMS/MODIS/MCD14DL.NRT.0061.'],
    ['Cuaca', `${CUACA.sumber}, titik ${CUACA.lokasi}. Data reanalisis (model iklim yang diasimilasi pengamatan, grid ±9–25 km), bukan stasiun di desa: cocok untuk melihat pola basah/kering dan perbandingan dengan normal, tetapi cenderung mencatat lebih banyak hari hujan ringan dibanding alat ukur di lapangan.`],
    ['Batas wilayah', (!SITE || SITE.id === 'nangalauk') ? 'Hutan Desa SK.685/Menlhk-PSKL/PKPS/PSL.0/2/2017; batas desa BIG 2020 (1:10.000); grid patroli 250 m PRCF Indonesia; batas kabupaten BIG 2021; fungsi kawasan SK.733/2014 jo. SK.6630/2021; tutupan lahan 2026; gambut Kementan (BBSDLP) 1:50.000.'
      : `${SITE.hd_nama} (${SITE.lphd || 'LPHD'}), Desa ${SITE.desa_nama}, Kec. ${SITE.kec}; ${SITE.sk ? 'Nomor SK ' + SITE.sk + (SITE.sk_tgl ? ' tanggal ' + tglID(SITE.sk_tgl) : '') : 'nomor SK belum tercantum pada data batas'}; luas areal ${fmt1(SITE.luas_hd_ha)} ha (dihitung dari poligon). Batas desa dari peta batas desa Kabupaten Kapuas Hulu; batas kabupaten BIG 2021. Petak patroli, fungsi kawasan, tutupan lahan dan gambut belum tersedia untuk lokasi ini.`],
    ['Pengolahan', 'Nilai asli FIRMS tidak diubah. Deteksi tipe gunung api, sumber panas statis (industri), dan lepas pantai tidak dihitung. Tren antar-tahun dibandingkan dalam sensor yang sama (VIIRS lebih peka dari MODIS).'],
    ['Jejak audit', `Setiap unduhan sumber dicatat (URL, waktu, SHA-256) di https://github.com/erikprcfi/hotspot-fire-prcf/tree/main/data/provenance. Basis data diperbarui ${STATUS.terakhir_cek_utc} (UTC). Setiap titik dapat dicek silang di https://firms.modaps.eosdis.nasa.gov/map.`],
    ['Bekas terbakar', 'Sentinel-2 L2A (ESA Copernicus, Earth Search AWS Open Data); indeks dNBR menurut Key & Benson (2006), FIREMON. Hasil berupa indikasi yang perlu verifikasi lapangan.'],
    ['Tutupan hutan', 'Hansen, M.C. dkk. (2013) High-Resolution Global Maps of 21st-Century Forest Cover Change. Science 342:850–853; Global Forest Change v1.13 (2000–2025), CC BY 4.0.'],
    ['Tutupan & penggunaan lahan', 'Potapov, P. dkk. (2022) The Global 2000–2020 Land Cover and Land Use Change Dataset Derived From the Landsat Archive. Frontiers in Remote Sensing 3:856903; GLAD GLCLUC v2, 30 m, CC BY 4.0.'],
    ['Karbon hutan', 'Harris, N.L. dkk. (2021) Global maps of twenty-first century forest carbon fluxes. Nature Climate Change 11:234–240; Gibbs, D.A. dkk. (2025) ESSD 17:1217–1243. Emisi bruto, serapan bruto & fluks bersih 2001–2025 versi 20260327; stok karbon 2000 versi 20230222. Data publik World Resources Institute, CC BY 4.0.'],
    ['Metode analisis area', 'Semua raster dibaca pada grid asli 0,00025° tanpa resampling; piksel masuk bila pusatnya di dalam batas; luas piksel geodesik. Kode: scripts/analisis_inti.py di https://github.com/erikprcfi/hotspot-fire-prcf (sama untuk area dampingan dan SHP unggahan).'],
    ['Bahaya kebakaran', 'Van Wagner, C.E. (1987) Development and Structure of the Canadian Forest Fire Weather Index System; de Groot dkk. (2006) Fire Danger Rating System Indonesia (dipakai BMKG). Input cuaca ERA5 (Copernicus C3S) dan analisis ECMWF.'],
    ['Keterbatasan', 'Satelit mendeteksi panas saat melintas (beberapa kali sehari); api kecil, singkat, atau di bawah tajuk dan saat tertutup awan dapat tidak terdeteksi. Luas terbakar perlu diukur dengan analisa citra (burn scar) atau lapangan.'],
    ['Sitasi', "We acknowledge the use of data and imagery from NASA's Fire Information for Resource Management System (FIRMS) (https://earthdata.nasa.gov/firms), part of NASA's Earth Science Data and Information System (ESDIS)."],
  ];
}
function figures(M) {
  const F = {};
  F.map = drawMap(M, 'wide'); F.zoom = drawMap(M, 'zoom');
  const lab = k => M.unit === 'bulan' ? BULAN[+k.slice(5, 7) - 1] + ' ' + k.slice(2, 4) : M.unit === 'hari' ? +k.slice(8, 10) + ' ' + BULAN[+k.slice(5, 7) - 1] : k;
  const zser = ZONES.slice(0, M.W.zmax + 1).map((z, i) => ({ name: z, color: ZCOL[i], values: M.per.map(p => p.z[i]) }));
  const gapMask = M.per.map(p => { if (!M.gap) return false; const s0 = M.unit === 'hari' ? p.k : M.unit === 'bulan' ? p.k + '-01' : p.k + '-01-01'; const e0 = M.unit === 'hari' ? p.k : M.unit === 'bulan' ? iso(new Date(Date.UTC(+p.k.slice(0, 4), +p.k.slice(5, 7), 0))) : p.k + '-12-31'; const s1 = s0 < M.a ? M.a : s0, e1 = e0 > M.b ? M.b : e0; return M.gap[0] <= s1 && M.gap[1] >= e1; });
  F.time = drawChart(`Titik panas & curah hujan per ${M.unit}`, M.per.map(p => lab(p.k)), zser.concat([{ name: 'Curah hujan (mm)', color: '#2F6FB0', type: 'line', values: M.per.map(p => p.rain === null ? null : Math.round(p.rain)) }]), { right: true, rlab: 'Curah hujan (mm)', gap: gapMask });
  if (M.unit === 'tahun') {
    const ys = M.per.map(p => p.k); const byF = f => ys.map(y => M.rows.filter(r => r.d.startsWith(y) && famOf(r.sen) === f).length);
    F.sensor = drawChart('Deteksi per tahun menurut sensor (bandingkan tren dalam sensor yang sama)', ys, [{ name: 'MODIS', color: '#8E7A9E', values: byF('MODIS') }, { name: 'VIIRS S-NPP', color: '#C9B21E', values: byF('VIIRS S-NPP') }, { name: 'VIIRS NOAA-20/21', color: '#E2621B', values: ys.map((y, i) => byF('VIIRS NOAA-20')[i] + byF('VIIRS NOAA-21')[i]) }]);
  }
  if (M.len > 120) {
    const cm = Array.from({ length: 12 }, (_, m) => M.rows.filter(r => +r.d.slice(5, 7) === m + 1).length);
    // rata-rata hujan bulanan HANYA dari bulan-bulan di dalam periode yang dipilih (bulan penuh)
    const rnorm = Array.from({ length: 12 }, (_, m) => { const per = {}; CUACA.t.forEach((t, i) => { if (t >= M.a && t <= M.b && +t.slice(5, 7) === m + 1) { const k = t.slice(0, 7); (per[k] = per[k] || [0, 0]); per[k][0] += CUACA.hujan[i] ?? 0; per[k][1]++; } });
      const full = Object.entries(per).filter(([k, v]) => v[1] >= new Date(Date.UTC(+k.slice(0, 4), +k.slice(5, 7), 0)).getUTCDate()); return full.length ? Math.round(full.reduce((p, [, v]) => p + v[0], 0) / full.length) : 0; });
    const y0 = M.a.slice(0, 4), y1 = M.b.slice(0, 4), yl = y0 === y1 ? y0 : `${y0}–${y1}`;
    F.season = drawChart(`Pola musim ${yl}: titik panas per bulan vs rata-rata curah hujan bulanan ${yl}`, BULAN, [{ name: `Titik panas ${yl}`, color: '#C9B21E', values: cm }, { name: `Rata-rata hujan ${yl} (mm/bulan)`, color: '#2F6FB0', type: 'line', values: rnorm }], { right: true, rlab: `Hujan rata-rata ${yl} (mm)` });
  }
  if (M.near.length && (!SITE || SITE.id === 'nangalauk')) F.ctx = drawContext(M);
  if (M.ex && M.ex.an) { const A = M.ex.an.hd, Y = A.tahun_tutupan.map(String), K = A.kelas.filter(k => Y.some(y => (A.tutupan_lahan_ha[y][k.kode] || 0) >= 0.05));
    F.lc = drawChart(`Tutupan lahan ${A.nama} 2000–2020 (GLAD), ha`, Y, K.map(k => ({ name: k.nama.split(' (')[0], color: k.warna === '#FFFFFF' ? '#DDDDDD' : k.warna, values: Y.map(y => Math.round(A.tutupan_lahan_ha[y][k.kode] || 0)) })), { ylab: 'Luas (ha)' });
    const ys = Object.keys(A.karbon.emisi_per_tahun_kehilangan_tCO2e);
    F.em = drawChart(`Emisi bruto (tCO2e) & kehilangan tutupan pohon (ha) per tahun – ${A.nama}`, ys, [{ name: 'Emisi bruto (tCO2e)', color: '#8E2A1E', values: ys.map(y => Math.round(A.karbon.emisi_per_tahun_kehilangan_tCO2e[y])) }, { name: 'Kehilangan pohon (ha)', color: '#E2621B', type: 'line', values: ys.map(y => A.hutan.kehilangan_per_tahun_ha[y]) }], { right: true, rlab: 'Kehilangan (ha)', ylab: 'Emisi (tCO2e)' }); }  // data kawasan/tutupan/gambut hanya tersedia untuk Nanga Lauk
  return F;
}

/* ---------------- data pelengkap (bekas terbakar, tutupan hutan, FDRS) & verifikasi ---------------- */
const JS = {};
async function getJ(u) { if (u in JS) return JS[u]; try { const r = await fetch(u + '?' + Date.now()); JS[u] = r.ok ? await r.json() : null; } catch (e) { JS[u] = null; } return JS[u]; }
const LVN = ['Rendah', 'Sedang', 'Tinggi', 'Ekstrem'];
async function extras(M) {
  const id = SITE ? SITE.id : 'nangalauk', ex = { id };
  const [bt, hk, fd, aHD, aDS] = await Promise.all([getJ('data/bekas_terbakar/indeks.json'), getJ('data/hutan/kehilangan.json'), getJ(`data/prakiraan/fdrs_${id}.json`), getJ(`data/analisis/${id}_hd.json`), getJ(`data/analisis/${id}_desa.json`)]);
  if (aHD && aDS) ex.an = { hd: aHD, desa: aDS, hk: hk && hk.lokasi && hk.lokasi[id] };
  ex.burnOk = !!(bt && bt.musim);
  if (ex.burnOk) ex.burn = Object.values(bt.musim).filter(m => m.lokasi === id && m.awal <= M.b && m.akhir >= M.a).sort((x, y) => x.awal.localeCompare(y.awal));
  const y0 = Math.max(2001, +M.a.slice(0, 4)), y1 = Math.min(2025, +M.b.slice(0, 4));
  if (hk && hk.lokasi && hk.lokasi[id] && y0 <= y1) {
    const L = hk.lokasi[id];
    ex.loss = { y0, y1, partial: (+M.a.slice(0, 4) >= 2001 && M.a.slice(5) !== '01-01') || (+M.b.slice(0, 4) <= 2025 && M.b.slice(5) !== '12-31'), after: +M.b.slice(0, 4) > 2025, sumber: hk.sumber, definisi: hk.definisi,
      zones: [['hutan_desa', 'Hutan Desa'], ['desa_di_luar_hd', 'Desa di luar Hutan Desa'], ['radius_0_5km', 'Radius 0–5 km di luar desa']].map(([k, n]) => {
        const z = L[k]; const per = {}; for (let y = y0; y <= y1; y++) per[y] = z.kehilangan_per_tahun_ha[String(y)] || 0;
        const tot = Object.values(per).reduce((p, c) => p + c, 0); return { k, n, luas: z.luas_wilayah_ha, hutan2000: z.hutan_2000_ha, per, tot };
      }) };
  }
  if (fd && fd.t) {
    const idx = []; fd.t.forEach((t, i) => { if (t >= M.a && t <= M.b && fd.level[i] != null) idx.push(i); });
    if (idx.length) {
      const c = [0, 0, 0, 0]; idx.forEach(i => c[fd.level[i]]++);
      ex.fdrs = { n: idx.length, t0: fd.t[idx[0]], t1: fd.t[idx[idx.length - 1]], c, first: fd.t[0], days: idx.map(i => ({ t: fd.t[i], h: fd.hujan[i], ffmc: fd.ffmc[i], dc: fd.dc[i], isi: fd.isi[i], fwi: fd.fwi[i], lv: fd.level[i], src: fd.sumber[i] })) };
    } else ex.fdrsFirst = fd.t[0];
  }
  return ex;
}
function extraSummary(M) {
  const s = [], ex = M.ex;
  const done = (ex.burn || []).filter(m => m.status === 'selesai');
  if (done.length) s.push(`Indikasi bekas terbakar (Sentinel-2, musim kebakaran yang beririsan dengan periode): ${fmt1(done.reduce((p, m) => p + m.luas_ha, 0))} ha dari ${done.length} musim yang dapat dianalisis` + ((ex.burn.length - done.length) ? `; ${ex.burn.length - done.length} musim lain tidak dapat diukur karena tertutup awan/citra kurang.` : '.'));
  if (ex.loss) { const hd = ex.loss.zones[0]; s.push(`Kehilangan tutupan pohon (Hansen GFC) ${ex.loss.y0 === ex.loss.y1 ? 'tahun ' + ex.loss.y0 : ex.loss.y0 + '–' + ex.loss.y1}: ${fmt1(hd.tot)} ha di Hutan Desa, ${fmt1(ex.loss.zones[1].tot)} ha di desa di luar Hutan Desa, ${fmt1(ex.loss.zones[2].tot)} ha di radius 0–5 km.`); }
  if (ex.an) { const H = ex.an.hd, C = H.karbon, sink = C.fluks_bersih_per_tahun_tCO2e < 0;
    s.push(`Analisis lahan & karbon ${H.nama} (data tahunan resmi, tidak bergantung periode laporan): hutan tahun 2000 ${fmt1(H.hutan.hutan_2000_ha)} ha, kehilangan tutupan pohon 2001–2025 ${fmt1(H.hutan.kehilangan_total_ha)} ha (${fmt1(H.hutan.persen_hilang)}%); emisi bruto ${fmt(C.emisi_bruto_per_tahun_tCO2e)} tCO2e/tahun, serapan ${fmt(C.serapan_bruto_per_tahun_tCO2)} tCO2/tahun, fluks bersih ${fmt(C.fluks_bersih_per_tahun_tCO2e)} tCO2e/tahun (${sink ? 'penyerap karbon bersih' : 'sumber emisi bersih'}); stok karbon total tahun 2000 ${fmt(C.stok_karbon_total_2000_tC)} tC.`); }
  if (ex.fdrs) s.push(`Indeks bahaya kebakaran (FDRS) tersedia untuk ${ex.fdrs.n} hari dalam periode: Rendah ${ex.fdrs.c[0]}, Sedang ${ex.fdrs.c[1]}, Tinggi ${ex.fdrs.c[2]}, Ekstrem ${ex.fdrs.c[3]} hari.`);
  return s;
}
function verify(M) {
  const C = [], add = (n, h, ok) => C.push([n, h, ok ? 'Sesuai' : 'Perlu perhatian']);
  const N = M.rows.length;
  const out = M.rows.filter(r => r.d < M.a || r.d > M.b).length;
  add('Semua deteksi berada di dalam periode yang dipilih', `${fmt(N)} deteksi; ${out} di luar ${M.a} s.d. ${M.b}`, out === 0);
  const oz = M.rows.filter(r => r.z > M.W.zmax).length;
  add('Semua deteksi berada di dalam wilayah laporan', `${oz} deteksi di luar wilayah "${M.W.nama}"`, oz === 0);
  const sx = M.sensor === 'semua' ? 0 : M.rows.filter(r => M.sensor === 'viirs' ? r.sen.startsWith('MODIS') : !r.sen.startsWith('MODIS')).length;
  add('Filter sensor sesuai pilihan', `pilihan: ${M.sensor === 'semua' ? 'VIIRS & MODIS' : M.sensor.toUpperCase()}; ${sx} deteksi sensor lain`, sx === 0);
  const ns = SITE ? M.rows.filter(r => !r.ls || r.ls.length <= SI).length : 0;
  add('Zona dihitung terhadap batas lokasi yang dipilih', `${SITE ? SITE.hd_nama + ', Desa ' + SITE.desa_nama : 'Nanga Lauk'}; ${ns} deteksi tanpa kode zona lokasi`, ns === 0);
  const zs = M.zc.reduce((p, c) => p + c, 0); add('Jumlah per zona (Tabel 1) = total', `${fmt(zs)} = ${fmt(N)}`, zs === N);
  const fs = M.fams.map(f => M.rows.filter(r => famOf(r.sen) === f).length).reduce((p, c) => p + c, 0); add('Jumlah per sensor (Tabel 1) = total', `${fmt(fs)} = ${fmt(N)}`, fs === N);
  const ps = M.per.reduce((p, c) => p + c.n, 0); add(`Jumlah per ${M.unit} (Tabel 2) = total`, `${fmt(ps)} = ${fmt(N)}`, ps === N);
  const u = new Set(M.rows.map(r => r.uid)).size; add('Tidak ada deteksi ganda', `${fmt(u)} ID unik dari ${fmt(N)} baris`, u === N);
  const en = M.events.reduce((p, e) => p + e.n, 0), nn = M.near.filter(r => r.ev).length; add('Deteksi dalam tabel kejadian = deteksi berkode kejadian di desa & 5 km', `${fmt(en)} = ${fmt(nn)}`, en === nn);
  const cd = CUACA.t.filter(t => t >= M.a && t <= M.b).length; add('Cakupan data cuaca harian', `${fmt(cd)} dari ${fmt(M.len)} hari (data s.d. ${tglID(CUACA.t[CUACA.t.length - 1])})`, cd === M.len);
  add('Kelengkapan arsip titik panas NASA FIRMS', M.gap ? `belum ada data ${tglID(M.gap[0])} – ${tglID(M.gap[1])} (menunggu arsip NASA)` : `lengkap untuk periode (basis data diperbarui ${STATUS.terakhir_cek_utc.replace('T', ' ').slice(0, 16)} UTC)`, !M.gap);
  if (M.ex.burn) { const bad = M.ex.burn.filter(m => m.lokasi !== M.ex.id || m.awal > M.b || m.akhir < M.a).length; add('Musim bekas terbakar sesuai lokasi & periode', `${M.ex.burn.length} musim beririsan; ${bad} tidak sesuai`, bad === 0); }
  if (M.ex.fdrs) { const bad = M.ex.fdrs.days.filter(d => d.t < M.a || d.t > M.b).length; add('Indeks FDRS hanya hari di dalam periode', `${M.ex.fdrs.n} hari; ${bad} di luar periode`, bad === 0); }
  if (M.ex.an) for (const [nm, A] of [['Hutan Desa', M.ex.an.hd], ['Desa', M.ex.an.desa]]) {
    const C = A.karbon, d = (C.emisi_bruto_total_tCO2e - C.serapan_bruto_total_tCO2) - C.fluks_bersih_total_tCO2e;
    add(`Karbon ${nm}: emisi bruto - serapan bruto = fluks bersih`, `${fmt(C.emisi_bruto_total_tCO2e)} - ${fmt(C.serapan_bruto_total_tCO2)} = ${fmt(C.emisi_bruto_total_tCO2e - C.serapan_bruto_total_tCO2)}; data: ${fmt(C.fluks_bersih_total_tCO2e)}`, Math.abs(d) <= Math.max(2, Math.abs(C.fluks_bersih_total_tCO2e) * 0.001));
    const lc = Object.values(A.tutupan_lahan_ha['2020']).reduce((p, c) => p + c, 0); add(`Tutupan lahan 2020 ${nm}: jumlah kelas = luas area`, `${fmt1(lc)} ha vs ${fmt1(A.luas_ha)} ha`, Math.abs(lc - A.luas_ha) <= Math.max(0.5, A.luas_ha * 0.002));
    const ls = Object.values(A.hutan.kehilangan_per_tahun_ha).reduce((p, c) => p + c, 0); add(`Kehilangan hutan ${nm}: jumlah per tahun = total`, `${fmt1(ls)} = ${fmt1(A.hutan.kehilangan_total_ha)} ha`, Math.abs(ls - A.hutan.kehilangan_total_ha) <= 0.2);
    const tp = Object.values(A.titik_panas.per_tahun).reduce((p, o) => p + Object.values(o).reduce((a, b) => a + b, 0), 0); add(`Titik panas jangka panjang ${nm}: jumlah per tahun = total`, `${fmt(tp)} = ${fmt(A.titik_panas.total)}`, tp === A.titik_panas.total);
  }
  if (M.ex.an && M.ex.an.hk) { const a = M.ex.an.hd.hutan.kehilangan_total_ha, b = M.ex.an.hk.hutan_desa.kehilangan_total_ha; add('Kehilangan hutan HD: analisis area = bab Hansen (dua perhitungan terpisah)', `${fmt1(a)} ha vs ${fmt1(b)} ha`, Math.abs(a - b) <= Math.max(0.5, b * 0.01)); }
  return C;
}
/* blok bagian tambahan, dipakai PDF, Word & pratinjau: {h, p:[...], t:[{cap, rows, note}]} */
function extraBlocks(M) {
  const ex = M.ex, B = [];
  // FDRS
  { const b = { h: 'Indeks bahaya kebakaran harian (FDRS)', p: [], t: [] };
    if (ex.fdrs) {
      const f = ex.fdrs; b.p.push(`Tingkat bahaya kebakaran harian dihitung dengan Canadian Fire Weather Index System (Van Wagner 1987) dari data cuaca analisis ERA5/ECMWF di pusat lokasi, dengan kelas Fire Danger Rating System Indonesia (de Groot dkk. 2006; dipakai BMKG): tingkat harian = kelas tertinggi dari FFMC (bahan bakar halus) dan DC (kekeringan lapisan dalam). Data tersedia ${tglID(f.t0)} – ${tglID(f.t1)} (${f.n} hari dari ${fmt(M.len)} hari periode).`);
      b.t.push({ cap: 'Jumlah hari menurut tingkat bahaya kebakaran', rows: [['Tingkat', 'Jumlah hari', 'Persen'], ...LVN.map((n, i) => [n, String(f.c[i]), fmt1(100 * f.c[i] / f.n) + '%'])] });
      const hi = f.days.filter(d => d.lv >= 2);
      if (hi.length) b.t.push({ cap: `Hari dengan tingkat Tinggi/Ekstrem (${hi.length})`, rows: [['Tanggal', 'Hujan (mm)', 'FFMC', 'DC', 'ISI', 'FWI', 'Tingkat'], ...hi.slice(0, 60).map(d => [tglID(d.t), fmt1(d.h), fmt1(d.ffmc), fmt(Math.round(d.dc)), fmt1(d.isi), fmt1(d.fwi), LVN[d.lv]])], note: hi.length > 60 ? `Ditampilkan 60 dari ${hi.length} hari.` : '' });
      else b.p.push('Tidak ada hari dengan tingkat Tinggi atau Ekstrem pada periode ini.');
    } else b.p.push(`Riwayat indeks bahaya kebakaran harian (FDRS) di sistem ini dimulai ${ex.fdrsFirst ? tglID(ex.fdrsFirst) : 'sejak sistem prakiraan aktif'}; periode yang dipilih tidak memiliki data FDRS. Kondisi cuaca periode ini tetap dilaporkan di bagian Cuaca (ERA5).`);
    B.push(b); }
  // Bekas terbakar
  { const b = { h: 'Indikasi luas bekas terbakar (Sentinel-2)', p: [], t: [] };
    b.p.push('Metode: citra Sentinel-2 L2A (ESA Copernicus) sebelum dan sesudah setiap musim kebakaran yang memiliki kejadian api di desa & radius 5 km; piksel dianggap terbakar bila dNBR ≥ 0,27 (Key & Benson 2006), reflektansi SWIR2 naik ≥ 0,02, NBR sesudah ≤ 0,20 di ≥ 2 citra cerah, petak ≥ 0,5 ha dan ≤ 1 km dari titik panas. Hasil adalah INDIKASI dari citra 20 m dan perlu verifikasi lapangan. Analisis dimulai musim 2023.');
    if (!ex.burnOk) b.p.push('Data analisis bekas terbakar belum tersedia di basis data.');
    else if (!ex.burn.length) b.p.push(`Tidak ada musim kebakaran yang dianalisis untuk ${SITE ? SITE.hd_nama : 'lokasi ini'} pada periode ${M.periodeTxt}.`);
    else {
      b.t.push({ cap: 'Musim kebakaran yang beririsan dengan periode laporan', rows: [['Musim (awal – akhir kejadian)', 'Kejadian', 'Deteksi', 'Status', 'Luas indikasi (ha)', 'dNBR tinggi (ha)', 'Citra cerah', 'Citra sebelum', 'Citra sesudah'],
        ...ex.burn.map(m => [`${tglID(m.awal)} – ${tglID(m.akhir)}`, String(m.n_kejadian), String(m.n_deteksi), m.status === 'selesai' ? 'Terukur' : m.status === 'tertutup awan' ? 'Tertutup awan' : m.status, m.status === 'selesai' ? fmt1(m.luas_ha) : '–', m.status === 'selesai' ? fmt1(m.luas_tinggi_ha) : '–', m.cerah_persen != null ? m.cerah_persen + '%' : '–', (m.tanggal_sebelum || []).join(', ') || '–', (m.tanggal_sesudah || []).join(', ') || '–'])] });
      if (ex.burn.some(m => m.awal < M.a || m.akhir > M.b)) b.p.push('Catatan: satu musim dianalisis utuh; musim yang sebagian berada di luar periode laporan tetap ditampilkan utuh.');
      b.p.push(`Poligon bekas terbakar (SHP, UTM 49N) dapat diunduh: data/export/bekas_terbakar_${ex.id}_UTM49N_shp.zip.`);
    }
    B.push(b); }
  // Hansen
  { const b = { h: 'Kehilangan tutupan pohon tahunan (Hansen/UMD GFC)', p: [], t: [] };
    if (ex.loss) {
      const L = ex.loss, ys = []; for (let y = L.y0; y <= L.y1; y++) ys.push(y);
      b.p.push(`${L.definisi} Sumber: ${L.sumber}.`);
      b.t.push({ cap: 'Ringkasan per zona', rows: [['Zona', 'Luas wilayah (ha)', 'Hutan tahun 2000 (ha)', `Kehilangan ${L.y0 === L.y1 ? L.y0 : L.y0 + '–' + L.y1} (ha)`, '% dari hutan 2000'], ...L.zones.map(z => [z.n, fmt1(z.luas), fmt1(z.hutan2000), fmt1(z.tot), z.hutan2000 ? fmt1(100 * z.tot / z.hutan2000) + '%' : '–'])] });
      b.t.push({ cap: 'Kehilangan per tahun (ha)', rows: [['Tahun', ...L.zones.map(z => z.n), 'Jumlah'], ...ys.map(y => [String(y), ...L.zones.map(z => fmt1(z.per[y])), fmt1(L.zones.reduce((p, z) => p + z.per[y], 0))]), ['Jumlah', ...L.zones.map(z => fmt1(z.tot)), fmt1(L.zones.reduce((p, z) => p + z.tot, 0))]] });
      if (L.partial) b.p.push('Catatan: data Hansen bersifat tahunan; tahun yang hanya sebagian masuk periode laporan dihitung untuk satu tahun penuh.');
      if (L.after) b.p.push('Catatan: data Hansen GFC v1.13 tersedia sampai tahun 2025; perubahan setelah 2025 dipantau dengan peringatan perubahan tutupan Sentinel-2 di aplikasi.');
    } else b.p.push('Periode yang dipilih berada di luar cakupan data tahunan Hansen GFC (2001–2025). Perubahan tutupan terbaru dipantau melalui peringatan perubahan tutupan Sentinel-2 di aplikasi.');
    B.push(b); }
  // Analisis lahan & karbon (Hansen/UMD, GLAD, Harris dkk.) – data tahunan, cakupan tetap
  const AN = ex.an, Z = AN ? [['Hutan Desa', AN.hd], ['Wilayah desa', AN.desa]] : [];
  { const b = { h: 'Tutupan & penggunaan lahan 2000–2020 (GLAD)', p: [], t: [] };
    if (AN) {
      const K = AN.hd.kelas, Y = AN.hd.tahun_tutupan, used = K.filter(k => Z.some(([, A]) => Y.some(y => (A.tutupan_lahan_ha[String(y)][k.kode] || 0) >= 0.05)));
      b.p.push(`Bagian ini bersifat jangka panjang (2000–2020) dan tidak mengikuti periode laporan. Sumber: ${AN.hd.sumber.tutupan_lahan}. Kelas dikelompokkan dari legenda resmi GLAD; "lahan basah" = lahan yang tergenang musiman/permanen (rawa, gambut, tepian danau/sungai). Piksel dihitung bila pusatnya berada di dalam batas; luas piksel geodesik.`);
      for (const [nm, A] of Z) b.t.push({ cap: `${nm} – ${A.nama} (${fmt1(A.luas_ha)} ha): luas per kelas (ha)`, rows: [['Kelas', ...Y.map(String), 'Perubahan 2000–2020'], ...used.map(k => [k.nama, ...Y.map(y => fmt1(A.tutupan_lahan_ha[String(y)][k.kode] || 0)), (v => (v >= 0 ? '+' : '') + fmt1(v))((A.tutupan_lahan_ha['2020'][k.kode] || 0) - (A.tutupan_lahan_ha['2000'][k.kode] || 0))])] });
      for (const [nm, A] of Z) { const tr = Object.entries(A.perubahan_2000_2020_ha || {}).slice(0, 8); if (tr.length) b.t.push({ cap: `${nm}: perubahan kelas terbesar 2000 → 2020`, rows: [['Dari', 'Menjadi', 'Luas (ha)'], ...tr.map(([k, v]) => { const [x, y] = k.split('>'); return [(K.find(q => q.kode === x) || {}).nama || x, (K.find(q => q.kode === y) || {}).nama || y, fmt1(v)]; })] }); }
    } else b.p.push('Data analisis lahan untuk lokasi ini belum tersedia.');
    B.push(b); }
  { const b = { h: 'Karbon hutan & emisi gas rumah kaca 2001–2025', p: [], t: [] };
    if (AN) {
      b.p.push(`Sumber: ${AN.hd.sumber.fluks_karbon}; ${AN.hd.sumber.stok_karbon}. Emisi bruto mencakup CO2, CH4 dan N2O dari biomassa dan tanah (termasuk gambut) akibat hilangnya tutupan pohon; serapan bruto = penyerapan CO2 oleh hutan yang tetap/tumbuh; fluks bersih = emisi - serapan (negatif = penyerap karbon bersih). Nilai per tahun = total 25 tahun ÷ 25. Ini hasil model global dengan ketidakpastian; bukan pengganti inventarisasi karbon/MRV lapangan.`);
      b.t.push({ cap: 'Ringkasan karbon', rows: [['Indikator', ...Z.map(([n]) => n)],
        ['Luas area (ha)', ...Z.map(([, A]) => fmt1(A.luas_ha))], ['Hutan tahun 2000, tajuk ≥30% (ha)', ...Z.map(([, A]) => fmt1(A.hutan.hutan_2000_ha))], ['Kehilangan tutupan pohon 2001–2025 (ha)', ...Z.map(([, A]) => fmt1(A.hutan.kehilangan_total_ha))],
        ['Emisi bruto total (tCO2e)', ...Z.map(([, A]) => fmt(A.karbon.emisi_bruto_total_tCO2e))], ['Serapan bruto total (tCO2)', ...Z.map(([, A]) => fmt(A.karbon.serapan_bruto_total_tCO2))], ['Fluks bersih total (tCO2e)', ...Z.map(([, A]) => fmt(A.karbon.fluks_bersih_total_tCO2e))],
        ['Emisi bruto per tahun (tCO2e/th)', ...Z.map(([, A]) => fmt(A.karbon.emisi_bruto_per_tahun_tCO2e))], ['Serapan bruto per tahun (tCO2/th)', ...Z.map(([, A]) => fmt(A.karbon.serapan_bruto_per_tahun_tCO2))], ['Fluks bersih per tahun (tCO2e/th)', ...Z.map(([, A]) => fmt(A.karbon.fluks_bersih_per_tahun_tCO2e))],
        ['Status karbon bersih', ...Z.map(([, A]) => A.karbon.fluks_bersih_total_tCO2e < 0 ? 'Penyerap' : 'Sumber emisi')],
        ['Stok karbon atas tanah 2000 (tC)', ...Z.map(([, A]) => fmt(A.karbon.stok_karbon_atas_tanah_2000_tC))], ['Stok karbon total 2000, semua pool (tC)', ...Z.map(([, A]) => fmt(A.karbon.stok_karbon_total_2000_tC))],
        ['Rerata karbon total hutan (tC/ha)', ...Z.map(([, A]) => fmt1(A.karbon.rerata_karbon_total_hutan_2000_tC_ha))], ['Rerata karbon atas tanah hutan (tC/ha)', ...Z.map(([, A]) => fmt1(A.karbon.rerata_karbon_atas_tanah_hutan_2000_tC_ha))]] });
      const ys = Object.keys(AN.hd.karbon.emisi_per_tahun_kehilangan_tCO2e);
      b.t.push({ cap: 'Kehilangan tutupan pohon (ha) dan emisi bruto (tCO2e) menurut tahun', rows: [['Tahun', ...Z.flatMap(([n]) => [`${n}: hilang (ha)`, `${n}: emisi (tCO2e)`])], ...ys.map(y => [y, ...Z.flatMap(([, A]) => [fmt1(A.hutan.kehilangan_per_tahun_ha[y] || 0), fmt(A.karbon.emisi_per_tahun_kehilangan_tCO2e[y] || 0)])])] });
    } else b.p.push('Data karbon untuk lokasi ini belum tersedia.');
    B.push(b); }
  { const b = { h: 'Titik panas jangka panjang 2016–2025 (arsip tahunan NASA)', p: [], t: [] };
    if (AN) {
      const T0 = AN.hd.titik_panas, ys = Object.keys(T0.per_tahun), S = Object.keys(T0.per_tahun[ys[0]]);
      b.p.push(`Jumlah deteksi titik panas tipe vegetasi dari arsip tahunan final NASA FIRMS di dalam batas Hutan Desa dan wilayah desa (VIIRS S-NPP, VIIRS NOAA-20, MODIS). ${T0.catatan}`);
      b.t.push({ cap: 'Deteksi per tahun dan sensor', rows: [['Tahun', ...Z.flatMap(([n]) => S.map(s => `${n}: ${s}`))], ...ys.map(y => [y, ...Z.flatMap(([, A]) => S.map(s => fmt(A.titik_panas.per_tahun[y][s])))]), ['Jumlah', ...Z.flatMap(([, A]) => S.map(s => fmt(ys.reduce((p, y) => p + A.titik_panas.per_tahun[y][s], 0))))]] });
    } else b.p.push('Data titik panas jangka panjang belum tersedia.');
    B.push(b); }
  { const b = { h: 'Wilayah administrasi yang tercakup', p: [], t: [] };
    if (AN) { b.p.push(`Desa/kelurahan yang beririsan dengan batas (batas BPS/BIG, OCHA COD-AB 2020; nama Kepmendagri No. 300.2.2-2430 Tahun 2025).`);
      for (const [nm, A] of Z) if (A.wilayah && A.wilayah.length) b.t.push({ cap: nm, rows: [['Desa/Kelurahan', 'Kecamatan', 'Kabupaten/Kota', 'Provinsi', '% desa tercakup'], ...A.wilayah.slice(0, 15).map(w => [w.desa, w.kec, w.kab, w.prov, fmt1(w.persen_desa_tercakup)])] }); }
    B.push(b); }
  B[7] = null;
  if (M.karbon) { const K = M.karbon, b = { h: `Emisi karbon hutan metode FREL (${K.periode})`, p: [], t: [] };
    b.p.push(`Perhitungan beda stok sesuai templat perhitungan karbon PRCF: Emisi (Mg CO2) = [luas deforestasi × (stok hutan − stok lahan terdeforestasi) + luas degradasi × (stok primer − stok sekunder)] × 44/12, kepadatan karbon FREL 2022. Tahun data aktivitas: ${K.y0}–${K.y1} (tahun kalender laporan). Sumber tutupan lahan: ${K.sumber || 'Model KLHK 2020 + Hansen GFC v1.13'} – sama dengan alat Tutupan lahan & Emisi karbon.`);
    b.p.push(`Deforestasi ${fmt1(K.defo)} ha, degradasi ${fmt1(K.degr)} ha; ${K.sumber_id === 'klhk' ? `kehilangan tutupan pohon di areal bukan hutan ${fmt1(K.nh)} ha (tidak dihitung sebagai emisi)` : `regenerasi bukan hutan → hutan ${fmt1(K.tumbuh)} ha (dicatat terpisah, tidak mengurangi emisi)`}. Emisi skenario awal ${fmt(Math.round(K.emisi_thn))} Mg CO2 (ΣK × 44/12); manfaat iklim ${fmt(Math.round(K.manfaat_thn))} Mg CO2/thn; sertifikat dapat dijual ${fmt(Math.round(K.jual_thn))} Mg CO2/thn; luas hutan terlindungi ${fmt1(K.terlindungi)} ha.`);
    b.t.push({ cap: 'Luas & pengurangan cadangan karbon per tipe hutan (sheet Awal)', rows: [['Tipe hutan', `Luas ${K.y0} (ha)`, 'Deforestasi (ha)', 'Degradasi (ha)', `Luas ${K.y1} (ha)`, 'Pengurangan C (Mg C)'], ...K.baris.map(r => [r[0], fmt1(r[1]), r[2].toFixed(4).replace('.', ','), r[3].toFixed(4).replace('.', ','), fmt1(r[4]), fmt1(r[5])])],
      note: 'Rincian lengkap (Parameter, Awal, Manfaat, per hektare) dan berkas Excel dengan rumus hidup tersedia di menu Emisi karbon (FREL). ' + K.metode.slice(0, 3).join(' ') });
    B[7] = b; }
  B[8] = null;
  if (M.lk && M.lk.kelas_ha) { const K = M.lk, P = K.prioritas || {}, ks = Object.keys(K.kelas_ha);
    B[8] = { h: `Lahan kritis (peta ${K.tahun})`, p: [`Peta Lahan Kritis Kabupaten Kapuas Hulu ${K.tahun} dipotong di batas Hutan Desa (luas UTM 49N). Prioritas rehabilitasi (Kritis/Sangat Kritis pada tutupan bukan hutan): ${fmt1(P.kritis_bukan_hutan_ha || 0)} ha; Agak Kritis pada bukan hutan: ${fmt1(P.agak_kritis_bukan_hutan_ha || 0)} ha; Agak Kritis–Sangat Kritis yang masih berhutan (prioritas perlindungan): ${fmt1(P.kritis_di_hutan_ha || 0)} ha. Tutupan lahan acuan: ${K.silang_tutupan ? K.silang_tutupan.sumber_tutupan : '–'}.`],
      t: [{ cap: 'Luas per kelas lahan kritis', rows: [['Kelas', 'Luas (ha)', '%'], ...ks.map(k => [k, fmt1(K.kelas_ha[k]), fmt1(K.kelas_persen[k] || 0) + '%'])] }] }; }
  return B;
}
function kpis(M) {
  const z = M.zc, ex = M.ex, done = (ex.burn || []).filter(m => m.status === 'selesai');
  const K = [['Total deteksi', fmt(M.rows.length)], ['Di Hutan Desa', fmt(z[0])], ['Di desa (luar HD)', fmt(z[1])], ['Radius 0–5 km', fmt(z[2])], ['Kejadian api (desa & 5 km)', fmt(M.events.length)],
    ['Curah hujan (mm)', M.rs ? fmt(Math.round(M.rs.sum)) + (M.rn ? ` (${Math.round(100 * M.rs.sum / M.rn)}% normal)` : '') : '–']];
  K.push(['Indikasi bekas terbakar (ha)', done.length ? fmt1(done.reduce((p, m) => p + m.luas_ha, 0)) : '–']);
  K.push(['Kehilangan pohon di HD (ha)', ex.loss ? fmt1(ex.loss.zones[0].tot) : '–']);
  return K;
}

/* ---------------- pratinjau ---------------- */
function htmlTable(t, max) { const rows = max ? t.slice(0, max + 1) : t; return `<div class="tw"><table><thead><tr>${rows[0].map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.slice(1).map(r => `<tr>${r.map(v => `<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` + (max && t.length - 1 > max ? `<p class="rp-note">… ${t.length - 1 - max} baris lainnya ada di file PDF/Word/CSV.</p>` : ''); }
function params(M) {
  return [['Lokasi', SITE ? `${SITE.hd_nama} (${SITE.lphd || 'LPHD'}), Desa ${SITE.desa_nama}, Kec. ${SITE.kec}, Kab. Kapuas Hulu` : 'Hutan Desa Nanga Lauk'],
    ['Dasar hukum', SITE && SITE.sk ? `${SITE.sk}${SITE.sk_tgl ? ', tanggal ' + tglID(SITE.sk_tgl) : ''}` : '–'],
    ['Wilayah laporan', M.W.nama], ['Periode', `${M.periodeTxt} (${fmt(M.len)} hari)`], ['Sensor', M.sensor === 'semua' ? 'VIIRS & MODIS' : M.sensor.toUpperCase()],
    ['Basis data diperbarui', STATUS.terakhir_cek_utc.replace('T', ' ').slice(0, 16) + ' UTC'], ['Laporan dibuat', M.dibuat]];
}
function preview(M, F, T) {
  const img = c => `<img src="${c.toDataURL('image/png')}" alt="" style="width:100%;max-width:900px;border:1px solid var(--line);margin:6px 0">`;
  const XB = extraBlocks(M); let n = 0; const h = t => `<h4>${++n}. ${esc(t)}</h4>`;
  const blk = b => h(b.h) + b.p.map(x => `<p>${esc(x)}</p>`).join('') + b.t.map(t => `<p class="rp-note">${esc(t.cap)}</p>${htmlTable(t.rows, 30)}${t.note ? `<p class="rp-note">${esc(t.note)}</p>` : ''}`).join('');
  const bad = M.checks.filter(c => c[2] !== 'Sesuai').length;
  $('#rpPreview').innerHTML = `<div class="rp-doc">${LOGO ? `<div style="display:flex;align-items:center;gap:12px;border-bottom:2px solid #22382B;padding-bottom:10px;margin-bottom:14px"><img src="${LOGO.url}" alt="PRCF Indonesia" style="height:46px;width:auto;border-radius:4px"><div><b style="font-size:15px">Yayasan PRCF Indonesia</b><div class="rp-note" style="margin:0">Pantau Rimbak · Monitoring, Reporting & Verification Hutan Desa</div></div></div>` : ''}<h3>${esc(M.title)}</h3>
  <div class="tw"><table><tbody>${params(M).map(([k, v]) => `<tr><th style="text-align:left;width:34%">${esc(k)}</th><td>${esc(v)}</td></tr>`).join('')}</tbody></table></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin:12px 0">${kpis(M).map(([k, v]) => `<div style="border:1px solid var(--line);border-radius:10px;padding:8px 10px"><div style="font:700 18px var(--f-data,monospace)">${esc(v)}</div><div class="rp-note" style="margin:0">${esc(k)}</div></div>`).join('')}</div>
  <p class="rp-note" style="color:${bad ? '#B3261E' : '#2E7D4F'}">Verifikasi otomatis: ${M.checks.length - bad} dari ${M.checks.length} pemeriksaan sesuai${bad ? ' — lihat Lampiran B' : ''}.</p>
  ${h('Ringkasan eksekutif')}<ul>${M.summary.map(s => `<li>${esc(s)}</li>`).join('')}</ul>
  ${h('Cuaca dan kaitannya dengan titik panas')}${M.weatherTxt.map(s => `<p>${esc(s)}</p>`).join('')}
  ${blk(XB[0])}
  ${h('Peta')}${img(F.map)}${img(F.zoom)}
  ${h('Grafik')}${img(F.time)}${F.sensor ? img(F.sensor) : ''}${F.season ? img(F.season) : ''}${F.ctx ? img(F.ctx) : ''}
  ${h('Rekapitulasi')}<p class="rp-note">Tabel 1. Deteksi per zona dan sensor</p>${htmlTable(T.zona)}<p class="rp-note">Tabel 2. Deteksi dan curah hujan per ${M.unit}</p>${htmlTable(T.periode, 40)}${T.petak.length > 1 ? `<p class="rp-note">Tabel 3. Petak patroli dengan titik panas</p>${htmlTable(T.petak)}` : ''}
  ${h(`Kejadian api di desa & radius 5 km (${M.events.length})`)}${T.ev.length > 1 ? htmlTable(T.ev, 15) : '<p>Tidak ada kejadian.</p>'}
  ${blk(XB[1])}${blk(XB[2])}
  ${XB[3] ? blk(XB[3]) + (F.lc ? img(F.lc) : '') + blk(XB[4]) + (F.em ? img(F.em) : '') + blk(XB[5]) + blk(XB[6]) : ''}
  ${XB[7] ? blk(XB[7]) : ''}
  ${XB[8] ? blk(XB[8]) : ''}
  <h4>Lampiran A. Detail deteksi di desa & radius 5 km (${M.near.length})</h4>${T.detail.length > 1 ? htmlTable(T.detail, 30) : '<p>Tidak ada deteksi.</p>'}
  <h4>Lampiran B. Verifikasi data</h4>${htmlTable(T.cek)}
  <h4>Lampiran C–D. Kamus data, sumber data & jejak audit</h4><p class="rp-note">Lihat file PDF/Word.</p></div>`;
}

/* ---------------- PDF ---------------- */
const TR = x => (window.FHLang ? FHLang.t(x) : x);
const pdfTxt = s => String(TR(String(s ?? ''))).replace(/≤/g, '<=').replace(/≥/g, '>=').replace(/…/g, '...').replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/µ/g, 'u').replace(/·/g, '-').replace(/→/g, '->').replace(/−/g, '-').replace(/₂/g, '2');
async function exportPDF(M, F, T) {
  await loadScript('vendor/jspdf.umd.min.js');
  await loadScript('vendor/jspdf.plugin.autotable.min.js');
  const { jsPDF } = window.jspdf; const doc = new jsPDF({ unit: 'mm', format: 'a4' }); if (window.FHLang) FHLang.pdf(doc); const PW = 210, ML = 16, CW = PW - 2 * ML; let y = 24;
  const TOC = []; let sec = 0;
  const need = h => { if (y + h > 280) { doc.addPage('a4', 'portrait'); y = 24; } };
  const H1 = (t, num = true, keep = 16) => { need(keep); const tt = num ? `${++sec}. ${t}` : t; TOC.push([tt, doc.getNumberOfPages()]); doc.setFillColor(HEAD); doc.rect(ML, y - 4.6, 1.6, 6.2, 'F'); doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(HEAD); doc.text(pdfTxt(tt), ML + 4, y); y += 8; };
  const P = (t, size = 9.5, col = INK, style = 'normal') => { doc.setFont('helvetica', style); doc.setFontSize(size); doc.setTextColor(col); const lines = doc.splitTextToSize(pdfTxt(t), CW); for (const l of lines) { need(5); doc.text(l, ML, y); y += size * 0.46; } y += 1.5; };
  const CAP = t => P(t, 8.5, MUTED, 'bold');
  const IMGp = (c, wmm) => { const h = wmm * c.height / c.width; need(h + 2); doc.addImage(c.toDataURL('image/jpeg', 0.9), 'JPEG', ML + (CW - wmm) / 2, y, wmm, h); y += h + 3; };
  const TAB = (t, fs = 7.5, opts = {}) => { doc.autoTable({ startY: y, head: [t[0].map(pdfTxt)], body: t.slice(1).map(r => r.map(pdfTxt)), margin: { left: ML, right: ML, top: 22 }, styles: { fontSize: fs, cellPadding: 1.2, textColor: INK, lineColor: LINE, lineWidth: 0.1 }, headStyles: { fillColor: HEAD, textColor: 255 }, alternateRowStyles: { fillColor: [241, 244, 241] }, ...opts }); y = doc.lastAutoTable.finalY + 5; };
  const BLK = b => { H1(b.h); b.p.forEach(x => P(x)); b.t.forEach(t => { CAP(t.cap); TAB(t.rows, t.rows[0].length > 7 ? 6.6 : 7.8); if (t.note) P(t.note, 8, MUTED); }); };
  /* ---- sampul ---- */
  doc.setFillColor(HEAD); doc.rect(0, 0, PW, 112, 'F');
  if (LOGO) { const lw = 30, lh = lw * LOGO.r; doc.setFillColor(255, 255, 255); doc.roundedRect(ML - 2, 14, lw + 4, lh + 4, 2, 2, 'F'); doc.addImage(LOGO.url, 'JPEG', ML, 16, lw, lh); }
  if (window.__PRL) doc.addImage(window.__PRL.url, 'PNG', PW - ML - 30, 12, 30, 30);
  doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text('Yayasan PRCF Indonesia', ML + 38, 24);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.text('Pantau Rimbak - Monitoring, Reporting & Verification Hutan Desa', ML + 38, 29.5);
  doc.setFontSize(9); doc.setFont('helvetica', 'bold'); doc.setTextColor(214, 228, 218); doc.text('LAPORAN PEMANTAUAN TITIK PANAS & KEBAKARAN', ML, 62);
  doc.setTextColor(255, 255, 255); doc.setFontSize(20); let cy = 71; doc.splitTextToSize(pdfTxt(SITE ? SITE.hd_nama : M.title), CW).forEach(l => { doc.text(l, ML, cy); cy += 8.5; });
  doc.setFont('helvetica', 'normal'); doc.setFontSize(11); doc.text(pdfTxt(`Periode ${M.periodeTxt}`), ML, cy + 1); cy += 7;
  doc.setFontSize(9); doc.setTextColor(214, 228, 218); doc.splitTextToSize(pdfTxt(M.W.nama), CW).forEach(l => { doc.text(l, ML, cy); cy += 4.5; });
  y = 122; doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5); doc.setTextColor(HEAD); doc.text('Parameter laporan (sesuai pilihan pengguna)', ML, y); y += 2;
  doc.autoTable({ startY: y, body: params(M).map(r => r.map(pdfTxt)), margin: { left: ML, right: ML }, theme: 'plain', styles: { fontSize: 8.5, cellPadding: 1.3, textColor: INK }, columnStyles: { 0: { cellWidth: 42, fontStyle: 'bold', textColor: MUTED } } });
  y = doc.lastAutoTable.finalY + 6;
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5); doc.setTextColor(HEAD); doc.text('Angka kunci periode ini', ML, y); y += 3;
  const K = kpis(M), bw = (CW - 3 * 4) / 4, bh = 21;
  K.forEach(([k, v], i) => { const x = ML + (i % 4) * (bw + 4), yy = y + Math.floor(i / 4) * (bh + 4); doc.setDrawColor(LINE); doc.setFillColor(246, 248, 246); doc.roundedRect(x, yy, bw, bh, 2, 2, 'FD');
    doc.setFillColor(i === 1 ? '#C21D1D' : i === 2 ? '#E2621B' : i === 3 ? '#E8A317' : HEAD); doc.rect(x, yy + 2, 1.2, bh - 4, 'F');
    const [big, small] = pdfTxt(v).split(' (');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.setTextColor(INK); doc.text(big, x + 4, yy + 9);
    if (small) { doc.setFontSize(7); doc.setTextColor(MUTED); doc.text('(' + small, x + 4, yy + 13); }
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7.3); doc.setTextColor(MUTED); doc.splitTextToSize(pdfTxt(k), bw - 6).forEach((l, j) => doc.text(l, x + 4, yy + 17 + j * 3)); });
  y += 2 * (bh + 4) + 4;
  const bad = M.checks.filter(c => c[2] !== 'Sesuai').length;
  doc.setFillColor(bad ? '#FCEDEA' : '#E8F3EC'); doc.roundedRect(ML, y, CW, 11, 2, 2, 'F'); doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(bad ? '#B3261E' : '#1E6B3E');
  doc.text(pdfTxt(`Verifikasi otomatis: ${M.checks.length - bad} dari ${M.checks.length} pemeriksaan konsistensi data sesuai${bad ? ' - lihat Lampiran B' : ''}.`), ML + 4, y + 6.8); y += 16;
  P('Sumber data resmi: NASA FIRMS (titik panas), Copernicus ERA5 & ECMWF (cuaca), ESA Copernicus Sentinel-2 (bekas terbakar), Hansen/UMD Global Forest Change (tutupan pohon). Nilai asli sumber tidak diubah; metode dan jejak audit di Lampiran D.', 7.8, MUTED);
  /* ---- daftar isi (diisi di akhir) ---- */
  doc.addPage('a4', 'portrait'); const tocPage = doc.getNumberOfPages();
  doc.addPage('a4', 'portrait'); y = 24;
  H1('Ringkasan eksekutif'); M.summary.forEach(s => P('• ' + s));
  H1('Cuaca dan kaitannya dengan titik panas'); M.weatherTxt.forEach(s => P(s));
  const XB = extraBlocks(M); BLK(XB[0]);
  H1('Peta', true, 120); IMGp(F.map, 150); IMGp(F.zoom, 150);
  H1('Grafik', true, 20 + CW * F.time.height / F.time.width); IMGp(F.time, CW); if (F.sensor) IMGp(F.sensor, CW); if (F.season) IMGp(F.season, CW); if (F.ctx) IMGp(F.ctx, CW);
  H1('Rekapitulasi'); CAP('Tabel 1. Deteksi per zona dan sensor'); TAB(T.zona, 8);
  CAP(`Tabel 2. Deteksi dan curah hujan per ${M.unit}`); TAB(T.periode, 7.5);
  if (T.petak.length > 1) { CAP('Tabel 3. Petak patroli dengan titik panas'); TAB(T.petak, 7.5, { columnStyles: { 2: { cellWidth: 120 } } }); }
  if (T.tindak && T.tindak.length > 1) { CAP('Tabel 4. Tindak lanjut dan verifikasi lapangan'); P(tindakRingkas(T.tindak), 8.5, MUTED); TAB(T.tindak.slice(0, 201), 7.5); }
  H1(`Kejadian api di desa & radius 5 km (${M.events.length})`);
  if (T.ev.length > 1) { if (M.events.length > CAP_EVENTS) P(`Ditampilkan ${CAP_EVENTS} kejadian (diurutkan dari zona terdekat). Seluruh kejadian ada di file CSV.`, 8.5, MUTED); TAB(T.ev, 7); } else P('Tidak ada kejadian pada periode ini.');
  BLK(XB[1]); BLK(XB[2]);
  if (XB[3]) { BLK(XB[3]); if (F.lc) IMGp(F.lc, CW); BLK(XB[4]); if (F.em) IMGp(F.em, CW); BLK(XB[5]); BLK(XB[6]); }
  if (XB[7]) BLK(XB[7]); if (XB[8]) BLK(XB[8]);
  doc.addPage('a4', 'landscape'); y = 24; const ML2 = 12;
  TOC.push([`Lampiran A. Detail deteksi di Hutan Desa, desa & radius 5 km (${M.near.length})`, doc.getNumberOfPages()]);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(12.5); doc.setTextColor(HEAD); doc.text(pdfTxt(TOC[TOC.length - 1][0]), ML2, y); y += 5;
  if (T.detailNote) { doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(MUTED); doc.text(pdfTxt(T.detailNote), ML2, y + 2); y += 6; }
  if (T.detail.length > 1) { doc.autoTable({ startY: y + 2, head: [T.detail[0].map(pdfTxt)], body: T.detail.slice(1).map(r => r.map(pdfTxt)), margin: { left: ML2, right: ML2, top: 22 }, styles: { fontSize: 6.8, cellPadding: 1, textColor: INK, lineColor: LINE, lineWidth: 0.1 }, headStyles: { fillColor: HEAD, textColor: 255 }, alternateRowStyles: { fillColor: [241, 244, 241] } }); y = doc.lastAutoTable.finalY + 6; }
  else { doc.setFontSize(9.5); doc.text('Tidak ada deteksi pada periode ini.', ML2, y + 6); y += 12; }
  doc.addPage('a4', 'portrait'); y = 24;
  H1('Lampiran B. Verifikasi data', false); P('Pemeriksaan konsistensi otomatis atas data yang masuk ke laporan ini, dijalankan saat laporan dibuat.', 8.8, MUTED);
  TAB(T.cek, 8, { columnStyles: { 0: { cellWidth: 70 }, 2: { cellWidth: 26, fontStyle: 'bold' } }, didParseCell: c => { if (c.section === 'body' && c.column.index === 2) c.cell.styles.textColor = c.cell.raw === 'Sesuai' ? [30, 107, 62] : [179, 38, 30]; } });
  H1('Lampiran C. Kamus data', false); TAB(T.kamus, 8, { columnStyles: { 0: { cellWidth: 35 } } });
  H1('Lampiran D. Sumber data, metode & jejak audit', false); sources(M).forEach(([k, v]) => P(`${k}. ${v}`, 8.8));
  /* ---- isi daftar isi ---- */
  doc.setPage(tocPage); let ty = 30; doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.setTextColor(HEAD); doc.text('Daftar isi', ML, ty); ty += 10;
  TOC.forEach(([t, pg]) => { doc.setFont('helvetica', /^\d/.test(t) ? 'normal' : 'italic'); doc.setFontSize(10); doc.setTextColor(INK); const tt = pdfTxt(t).slice(0, 95); doc.text(tt, ML, ty); const w = doc.getTextWidth(tt);
    doc.setTextColor(MUTED); doc.text('.'.repeat(Math.max(2, Math.floor((CW - w - 12) / doc.getTextWidth('.')))), ML + w + 2, ty); doc.setTextColor(INK); doc.text(String(pg), PW - ML, ty, { align: 'right' }); ty += 7.5; });
  const n = doc.getNumberOfPages();
  for (let i = 2; i <= n; i++) { doc.setPage(i); const w = doc.internal.pageSize.getWidth(), h = doc.internal.pageSize.getHeight();
    if (LOGO) doc.addImage(LOGO.url, 'JPEG', 12, 6, 9, 9 * LOGO.r); if (window.__PRL) doc.addImage(window.__PRL.url, 'PNG', w / 2 - 4, 5.5, 8, 8); doc.setFont('helvetica', 'bold'); doc.setFontSize(7.5); doc.setTextColor(HEAD); doc.text('Yayasan PRCF Indonesia - Pantau Rimbak', 24, 10.5);
    doc.setFont('helvetica', 'normal'); doc.setTextColor(MUTED); doc.text(pdfTxt(`${SITE ? SITE.hd_nama : ''} | ${M.periodeTxt}`), w - 12, 10.5, { align: 'right' }); doc.setDrawColor(LINE); doc.setLineWidth(0.3); doc.line(12, 15.5, w - 12, 15.5);
    doc.setFontSize(7.5); doc.text(pdfTxt(`${M.title} | ${M.periodeTxt}`).slice(0, 150), 12, h - 8); doc.text(`Halaman ${i} dari ${n}`, w - 12, h - 8, { align: 'right' }); }
  doc.save(fname(M, 'pdf')); return n;
}

/* ---------------- Word ---------------- */
async function exportDOCX(M, F, T) {
  await loadScript('vendor/docx.umd.js');
  const d = window.docx; const run = (t, o = {}) => new d.TextRun({ text: String(TR(String(t ?? ''))), font: 'Arial', size: o.size || 20, bold: o.bold, italics: o.it, color: o.color });
  const P = (t, o = {}) => new d.Paragraph({ children: [run(t, o)], spacing: { after: 100 }, bullet: o.bullet ? { level: 0 } : undefined });
  let sec = 0; const H = (t, num = true) => new d.Paragraph({ heading: d.HeadingLevel.HEADING_1, children: [run(num ? `${++sec}. ${t}` : t, { bold: true, size: 26, color: '22382B' })], spacing: { before: 240, after: 120 }, border: { left: { style: d.BorderStyle.SINGLE, size: 18, color: '22382B', space: 6 } } });
  const CAPd = t => P(t, { size: 17, color: '5B6A61', bold: true });
  const img = async (c, wcm) => { const blob = await new Promise(ok => c.toBlob(ok, 'image/png')); const buf = await blob.arrayBuffer(); const wpx = wcm * 37.8; return new d.Paragraph({ alignment: d.AlignmentType.CENTER, children: [new d.ImageRun({ data: buf, transformation: { width: wpx, height: wpx * c.height / c.width } })] }); };
  const cell = (v, o = {}) => new d.TableCell({ shading: o.fill ? { fill: o.fill, type: d.ShadingType.CLEAR, color: 'auto' } : undefined, width: o.w ? { size: o.w, type: d.WidthType.PERCENTAGE } : undefined, margins: { top: 40, bottom: 40, left: 80, right: 80 }, children: (Array.isArray(v) ? v : [v]).map(x => x instanceof d.Paragraph ? x : new d.Paragraph({ children: [run(x, o)] })) });
  const TB = (t, size = 15, stat) => new d.Table({ width: { size: 100, type: d.WidthType.PERCENTAGE }, rows: t.map((r, i) => new d.TableRow({ tableHeader: i === 0, children: r.map((v, j) => cell(v, { size, bold: i === 0 || (stat && j === 2), color: i === 0 ? 'FFFFFF' : stat && j === 2 ? (v === 'Sesuai' ? '1E6B3E' : 'B3261E') : undefined, fill: i === 0 ? '22382B' : i % 2 === 0 ? 'F1F4F1' : undefined })) })) });
  const BLKd = b => [H(b.h), ...b.p.map(x => P(x)), ...b.t.flatMap(t => [CAPd(t.cap), TB(t.rows, t.rows[0].length > 7 ? 13 : 15), ...(t.note ? [P(t.note, { size: 16, color: '5B6A61' })] : []), P('')])];
  let logoBuf = null; if (LOGO) { const bl = await new Promise(ok => LOGO.c.toBlob(ok, 'image/jpeg', 0.95)); logoBuf = await bl.arrayBuffer(); }
  const head = () => new d.Header({ children: [new d.Paragraph({ border: { bottom: { style: d.BorderStyle.SINGLE, size: 4, color: 'D3DBD5', space: 4 } }, tabStops: [{ type: d.TabStopType.RIGHT, position: 9900 }], children: [...(logoBuf ? [new d.ImageRun({ data: logoBuf, transformation: { width: 30, height: Math.round(30 * LOGO.r) } }), run('  ')] : []), run('Yayasan PRCF Indonesia – Pantau Rimbak', { size: 15, bold: true, color: '22382B' }), run(`\t${SITE ? SITE.hd_nama + ' | ' : ''}${M.periodeTxt}`, { size: 15, color: '5B6A61' })] })] });
  const foot = () => new d.Footer({ children: [new d.Paragraph({ alignment: d.AlignmentType.RIGHT, children: [run(`${M.title} | Halaman `, { size: 15, color: '5B6A61' }), new d.TextRun({ children: [d.PageNumber.CURRENT], font: 'Arial', size: 15, color: '5B6A61' })] })] });
  const K = kpis(M), bad = M.checks.filter(c => c[2] !== 'Sesuai').length;
  const kpiT = new d.Table({ width: { size: 100, type: d.WidthType.PERCENTAGE }, rows: [0, 1].map(r => new d.TableRow({ children: K.slice(r * 4, r * 4 + 4).map(([k, v]) => cell([new d.Paragraph({ children: [run(v, { size: 28, bold: true, color: '1D2A22' })] }), new d.Paragraph({ children: [run(k, { size: 15, color: '5B6A61' })] })], { fill: 'F6F8F6', w: 25 })) })) });
  const cover = [
    ...(logoBuf ? [new d.Paragraph({ children: [new d.ImageRun({ data: logoBuf, transformation: { width: 120, height: Math.round(120 * LOGO.r) } }), ...(window.__PRL ? [run('      '), new d.ImageRun({ data: Uint8Array.from(atob(window.__PRL.url.split(',')[1]), x => x.charCodeAt(0)), transformation: { width: 64, height: 64 } })] : [])] })] : []),
    new d.Paragraph({ children: [run('Yayasan PRCF Indonesia', { bold: true, size: 26, color: '22382B' })] }),
    new d.Paragraph({ children: [run('Pantau Rimbak · Monitoring, Reporting & Verification Hutan Desa', { size: 17, color: '5B6A61' })], border: { bottom: { style: d.BorderStyle.SINGLE, size: 12, color: '22382B', space: 6 } }, spacing: { after: 600 } }),
    new d.Paragraph({ children: [run('LAPORAN PEMANTAUAN TITIK PANAS & KEBAKARAN', { bold: true, size: 18, color: '5B6A61' })] }),
    new d.Paragraph({ children: [run(SITE ? SITE.hd_nama : M.title, { bold: true, size: 44, color: '22382B' })], spacing: { after: 80 } }),
    new d.Paragraph({ children: [run(`Periode ${M.periodeTxt}`, { size: 24 })], spacing: { after: 300 } }),
    CAPd('Parameter laporan (sesuai pilihan pengguna)'),
    new d.Table({ width: { size: 100, type: d.WidthType.PERCENTAGE }, rows: params(M).map(([k, v]) => new d.TableRow({ children: [cell(k, { size: 17, bold: true, color: '5B6A61', w: 28 }), cell(v, { size: 17, w: 72 })] })) }),
    P(''), CAPd('Angka kunci periode ini'), kpiT, P(''),
    P(`Verifikasi otomatis: ${M.checks.length - bad} dari ${M.checks.length} pemeriksaan konsistensi data sesuai${bad ? ' – lihat Lampiran B' : ''}.`, { size: 17, bold: true, color: bad ? 'B3261E' : '1E6B3E' }),
    P('Sumber data resmi: NASA FIRMS (titik panas), Copernicus ERA5 & ECMWF (cuaca), ESA Copernicus Sentinel-2 (bekas terbakar), Hansen/UMD Global Forest Change (tutupan pohon). Nilai asli sumber tidak diubah; metode dan jejak audit di Lampiran D.', { size: 15, color: '5B6A61' })];
  const toc = [new d.Paragraph({ children: [run('Daftar isi', { bold: true, size: 30, color: '22382B' })], spacing: { after: 200 } }), new d.TableOfContents(TR('Daftar isi'), { hyperlink: true, headingStyleRange: '1-1' }),
    P('(Jika daftar isi kosong, klik kanan lalu pilih "Update Field" di Microsoft Word.)', { size: 15, color: '5B6A61', it: true })];
  const XB = extraBlocks(M);
  const main = [H('Ringkasan eksekutif'), ...M.summary.map(s => P(s, { bullet: true })), H('Cuaca dan kaitannya dengan titik panas'), ...M.weatherTxt.map(s => P(s)), ...BLKd(XB[0]),
    H('Peta'), await img(F.map, 15), await img(F.zoom, 15), H('Grafik'), await img(F.time, 16.5)];
  if (F.sensor) main.push(await img(F.sensor, 16.5)); if (F.season) main.push(await img(F.season, 16.5)); if (F.ctx) main.push(await img(F.ctx, 16.5));
  main.push(H('Rekapitulasi'), CAPd('Tabel 1. Deteksi per zona dan sensor'), TB(T.zona), P(''), CAPd(`Tabel 2. Deteksi dan curah hujan per ${M.unit}`), TB(T.periode));
  if (T.petak.length > 1) main.push(P(''), CAPd('Tabel 3. Petak patroli dengan titik panas'), TB(T.petak));
  if (T.tindak && T.tindak.length > 1) main.push(P(''), CAPd('Tabel 4. Tindak lanjut dan verifikasi lapangan'), P(tindakRingkas(T.tindak), { size: 17, color: '5B6A61' }), TB(T.tindak.slice(0, 201), 14));
  main.push(H(`Kejadian api di desa & radius 5 km (${M.events.length})`));
  if (T.ev.length > 1) { if (M.events.length > CAP_EVENTS) main.push(P(`Ditampilkan ${CAP_EVENTS} kejadian (zona terdekat lebih dulu). Seluruh kejadian ada di file CSV.`, { size: 17, color: '5B6A61' })); main.push(TB(T.ev, 14)); } else main.push(P('Tidak ada kejadian pada periode ini.'));
  main.push(...BLKd(XB[1]), ...BLKd(XB[2]));
  if (XB[3]) { main.push(...BLKd(XB[3])); if (F.lc) main.push(await img(F.lc, 16.5)); main.push(...BLKd(XB[4])); if (F.em) main.push(await img(F.em, 16.5)); main.push(...BLKd(XB[5]), ...BLKd(XB[6])); }
  if (XB[7]) main.push(...BLKd(XB[7])); if (XB[8]) main.push(...BLKd(XB[8]));
  const app = [H(`Lampiran A. Detail deteksi di Hutan Desa, desa & radius 5 km (${M.near.length})`, false)]; if (T.detailNote) app.push(P(T.detailNote, { size: 17, color: '5B6A61' }));
  app.push(T.detail.length > 1 ? TB(T.detail, 13) : P('Tidak ada deteksi pada periode ini.'));
  const end = [H('Lampiran B. Verifikasi data', false), P('Pemeriksaan konsistensi otomatis atas data yang masuk ke laporan ini, dijalankan saat laporan dibuat.', { size: 17, color: '5B6A61' }), TB(T.cek, 16, true),
    H('Lampiran C. Kamus data', false), TB(T.kamus, 16), H('Lampiran D. Sumber data, metode & jejak audit', false), ...sources(M).map(([k, v]) => new d.Paragraph({ spacing: { after: 100 }, children: [run(k + '. ', { bold: true, size: 18 }), run(v, { size: 18 })] }))];
  const pg = { margin: { top: 1100, bottom: 1000, left: 1000, right: 1000 } };
  const docx = new d.Document({ creator: 'Yayasan PRCF Indonesia – Pantau Rimbak', title: TR(M.title), features: { updateFields: true }, styles: { paragraphStyles: [{ id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: 'Arial', size: 26, bold: true, color: '22382B' }, paragraph: { outlineLevel: 0, spacing: { before: 240, after: 120 } } }] },
    sections: [{ properties: { page: pg }, children: cover }, { properties: { page: pg }, headers: { default: head() }, footers: { default: foot() }, children: toc },
      { properties: { page: pg }, headers: { default: head() }, footers: { default: foot() }, children: main },
      { properties: { page: { ...pg, size: { orientation: d.PageOrientation.LANDSCAPE } } }, headers: { default: head() }, footers: { default: foot() }, children: app },
      { properties: { page: pg }, headers: { default: head() }, footers: { default: foot() }, children: end }] });
  const blob = await d.Packer.toBlob(docx); dl(blob, fname(M, 'docx'));
}

/* ---------------- CSV ---------------- */
function exportCSV(M) {
  const cols = ['waktu_wib', 'tanggal_utc', 'jam_utc', 'latitude', 'longitude', 'sensor', 'satelit', 'keyakinan', 'frp_mw', 'suhu_kecerahan_k', 'siang_malam', 'zona', 'jarak_desa_km', 'petak', 'fungsi_kawasan', 'tutupan_2026', 'gambut', 'status_data', 'id_kejadian', 'luas_piksel_ha_bukan_luas_terbakar', 'kabupaten', 'uid'];
  const q = v => { const s = String(v ?? ''); return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const tv = window.FHLang ? FHLang.nilai : (v => v), kc = window.FHLang ? FHLang.kolom : (v => v);
  const lines = [cols.map(kc).join(',')].concat(M.rows.map(r => [r.wib, r.d, r.t, r.lat, r.lon, r.sen, r.sat, r.conf, r.frp, r.bt, r.dn, ZONES[r.z], r.km, r.pt, r.kw, r.tl, r.gb, r.st, r.ev, r.ha, r.kab, r.uid].map(v => q(tv(v))).join(',')));
  dl(new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8' }), fname(M, 'csv'));
}
function dl(blob, name) { const u = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(u); a.remove(); }, 2000); }
function fname(M, ext) { const n = fnameId(M, ext); return window.FHLang && FHLang.get() === 'en' ? n.replace('laporan_titik_panas', 'hotspot_report').replace('data_titik_panas', 'hotspot_data').replace('_sd_', '_to_').replace('_desa_', '_village_').replace('_kabupaten_', '_regency_') : n; }
function fnameId(M, ext) { return `laporan_titik_panas_${SITE ? SITE.id + '_' : ''}${M.wilKey}_${M.a}_sd_${M.b}.${ext}`.replace('laporan_titik_panas', ext === 'csv' ? 'data_titik_panas' : 'laporan_titik_panas'); }

/* ---------- tindak lanjut & verifikasi lapangan (hanya bila pengguna masuk; tanpa nama petugas) ---------- */
async function tindakTabel(a, b) {
  const A = window.FHAlat; if (!A || !A.akun || !A.akun()) return null;
  const j = await A.api({ aksi: 'tindak_daftar' }, 30000); if (!j || !j.ok) return null;
  const t0 = Date.parse(a + 'T00:00:00Z') - 7 * 36e5, t1 = Date.parse(b + 'T23:59:59Z') - 7 * 36e5, hd = SITE ? SITE.hd_nama : '';
  const R = Object.values(j.status || {}).filter(x => x.dt && x.dt >= t0 && x.dt <= t1 && (!hd || !x.hd || x.hd === hd)).sort((p, q) => p.dt - q.dt);
  if (!R.length) return [];
  const w = ms => { const d = new Date(ms + 7 * 36e5); return d.toISOString().slice(0, 16).replace('T', ' '); };
  return [['No', 'Deteksi satelit (WIB)', 'Jenis', 'Status', 'Hasil verifikasi', 'Dicek di lapangan (WIB)'], ...R.map((x, i) => [String(i + 1), w(x.dt), x.jenis || 'Titik panas', x.s || 'Terdeteksi', x.h || '–', (x.w && x.w.cek) || '–'])];
}
function tindakRingkas(T) {
  const R = T.slice(1), dicek = R.filter(r => r[5] !== '–' || r[4] !== '–').length, hs = {}; R.forEach(r => { if (r[4] !== '–') hs[r[4]] = (hs[r[4]] || 0) + 1; });
  return `${R.length} kejadian tercatat di sistem tindak lanjut, ${dicek} di antaranya sudah dicek di lapangan.` + (Object.keys(hs).length ? ' Hasil: ' + Object.entries(hs).map(([h, n]) => `${h.toLowerCase()} ${n}`).join(', ') + '.' : '');
}

/* ---------------- UI ---------------- */
function presetRange(p) {
  const now = new Date(Date.now() + 7 * 36e5); const y = now.getUTCFullYear(), m = now.getUTCMonth(); const today = iso(now);
  const first = (yy, mm) => iso(new Date(Date.UTC(yy, mm, 1))), last = (yy, mm) => iso(new Date(Date.UTC(yy, mm + 1, 0)));
  switch (p) {
    case 'bulan_lalu': return [first(y, m - 1), last(y, m - 1)];
    case 'bulan_ini': return [first(y, m), today];
    case '3_bulan': return [first(y, m - 2), today];
    case 'tahun_lalu': return [`${y - 1}-01-01`, `${y - 1}-12-31`];
    case 'tahun_ini': return [`${y}-01-01`, today];
    case '12_bulan': return [iso(new Date(Date.UTC(y - 1, m, now.getUTCDate() + 1))), today];
    case 'semua': return ['2001-01-01', today];
  }
  return null;
}
async function run(kind) {
  const a = $('#rpFrom').value, b = $('#rpTo').value;
  if (!a || !b || a > b) return status('Isi tanggal mulai dan selesai dengan benar (mulai tidak boleh setelah selesai).', true);
  const btns = document.querySelectorAll('#rpForm button'); btns.forEach(x => x.disabled = true);
  try {
    status('Mengambil data dan menyusun laporan…');
    const key = [a, b, $('#rpWil').value, $('#rpSen').value, window.FH_SITE || ''].join('|');
    if (!LAST || LAST.key !== key) { const M = await buildModel(a, b, $('#rpWil').value, $('#rpSen').value); const F = figures(M), T = tables(M); LAST = { key, M, F, T }; preview(M, F, T); }
    if (!LAST.tl) { LAST.tl = 1; try { LAST.T.tindak = await tindakTabel(a, b); } catch (e) { LAST.T.tindak = null; } }
    const { M, F, T } = LAST;
    if (kind === 'pdf') { status('Membuat PDF…'); const n = await exportPDF(M, F, T); status(`PDF selesai (${n} halaman) dan sudah diunduh.`); }
    else if (kind === 'docx') { status('Membuat Word…'); await exportDOCX(M, F, T); status('File Word selesai dan sudah diunduh.'); }
    else if (kind === 'csv') { exportCSV(M); status(`CSV berisi ${fmt(M.rows.length)} baris sudah diunduh.`); }
    else status(`Laporan siap: ${fmt(M.rows.length)} deteksi. Periksa pratinjau di bawah, lalu unduh PDF/Word/CSV.`);
    if (kind === 'lihat') $('#rpPreview').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) { console.error(e); status('Gagal membuat laporan: ' + e.message + '. Coba muat ulang halaman.', true); }
  finally { btns.forEach(x => x.disabled = false); }
}
function init() {
  const sel = $('#rpPreset'); if (!sel) return;
  const apply = () => { const r = presetRange(sel.value); if (r) { $('#rpFrom').value = r[0] < '2001-01-01' ? '2001-01-01' : r[0]; $('#rpTo').value = r[1]; } LAST = null; };
  sel.addEventListener('change', apply); ['#rpFrom', '#rpTo', '#rpWil', '#rpSen'].forEach(s => $(s).addEventListener('change', () => { if (s === '#rpFrom' || s === '#rpTo') sel.value = 'kustom'; LAST = null; }));
  apply();
  const bl = $('#rpBulan'); if (bl) { const n = new Date(Date.now() + 7 * 36e5); bl.max = n.toISOString().slice(0, 7);
    bl.addEventListener('change', () => { const m = /^(\d{4})-(\d{2})$/.exec(bl.value); if (!m) return; const y = +m[1], mo = +m[2] - 1, f = iso(new Date(Date.UTC(y, mo, 1))), l = iso(new Date(Date.UTC(y, mo + 1, 0))), t = iso(new Date(Date.now() + 7 * 36e5));
      $('#rpFrom').value = f; $('#rpTo').value = l > t ? t : l; sel.value = 'kustom'; sel.dispatchEvent(new Event('sync')); document.querySelectorAll('[data-for="rpPreset"] .chip').forEach(c => c.setAttribute('aria-pressed', 'false')); LAST = null; }); }
  $('#rpLihat').addEventListener('click', () => run('lihat')); $('#rpPdf').addEventListener('click', () => run('pdf'));
  $('#rpDocx').addEventListener('click', () => run('docx')); $('#rpCsv').addEventListener('click', () => run('csv'));
  $('#rpTo').max = iso(new Date(Date.now() + 7 * 36e5));
}
window.PantauLaporan = { buildModel, figures, tables, exportPDF, exportDOCX, presetRange, reset: () => { LAST = null; } };
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
